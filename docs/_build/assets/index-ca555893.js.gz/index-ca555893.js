import{n as h,B as H,t as s,d as b,F as e,G as $,h as X,x as y}from"./web-195d4417.js";const f0=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   id="Capa_1"
   data-name="Capa 1"
   viewBox="0 0 745.75885 764.71716"
   version="1.1"
   sodipodi:docname="logo-hortifrut.svg"
   width="745.75885"
   height="764.71716"
   inkscape:version="1.0.2 (e86c870879, 2021-01-15, custom)">
  <metadata
     id="metadata111">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <sodipodi:namedview
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1"
     objecttolerance="10"
     gridtolerance="10"
     guidetolerance="10"
     inkscape:pageopacity="0"
     inkscape:pageshadow="2"
     inkscape:window-width="1920"
     inkscape:window-height="1017"
     id="namedview109"
     showgrid="false"
     fit-margin-top="0"
     fit-margin-left="0"
     fit-margin-right="0"
     fit-margin-bottom="0"
     inkscape:zoom="0.68068037"
     inkscape:cx="246.98541"
     inkscape:cy="442.76311"
     inkscape:window-x="-8"
     inkscape:window-y="-8"
     inkscape:window-maximized="1"
     inkscape:current-layer="Capa_1" />
  <defs
     id="defs4">
    <style
       id="style2">.cls-1{fill:#37b550;}.cls-2{fill:#135c43;}.cls-3{fill:none;stroke:#000;stroke-width:0.72px;}.cls-4{fill:#ee292b;}.cls-5{fill:#dc232a;}</style>
  </defs>
  <path
     class="cls-1"
     d="m 745.65882,269.58715 -0.06,-137.07 c 0,0 -138.95,-12.6 -274.1,76.94 0,0 74.52,29.33 109.7,74.81 0,0 107.8,-47.57 164.46,-14.68 z"
     id="path6" />
  <path
     class="cls-1"
     d="m 1.9188236,272.99715 -0.1,-137.09 c 0,0 179.0999964,-9.83 266.6299964,72.36 0,0 -81.56,37.09 -116.71,82.59 0,0 -93.229996,-50.81 -149.8199964,-17.86 z"
     id="path8" />
  <path
     class="cls-2"
     d="m 745.64882,262.26715 c 0,0 -100.5,-25.54 -164.45,22 0,0 69.49,69.41 86,175.41 h 78.56 z"
     id="path10" />
  <path
     class="cls-2"
     d="m 1.9188236,262.60715 c 0,0 85.8100004,-25.61 149.8199964,21.85 0,0 -58.459996,69.48 -74.839996,175.48 H 1.9688236 Z"
     id="path12" />
  <path
     class="cls-2"
     d="M 480.60882,121.06715 V 41.867152 c 0,0 -90.17,-25.53 -101.09,79.239998 v 51.32 h 5.65 c 0,0 -3.35,-66.63 95.44,-51.36 z"
     id="path14" />
  <path
     class="cls-2"
     d="m 361.38882,172.43715 c 0,0 12.73,-114.669998 -21.09,-148.929998 0,0 -26.51,-29.6800001 -79,-22.3400001 V 78.827152 c 0,0 82.23,-9.68 90,56.569998 0,0 3.67,28.82 3.66,37 z"
     id="path16" />
  <g
     id="g945"
     transform="matrix(0.97948124,0,0,0.97948124,-6.160937,1.6214369)">
    <path
       d="M 6.29,617 V 516.08 H 26.67 V 555.8 H 66.59 V 516.08 H 87 V 617 H 66.59 V 572.87 H 26.67 V 617 Z"
       id="path18" />
    <path
       d="m 98.69,567.16 q 0,-15.42 4.61,-25.89 a 47.42,47.42 0 0 1 9.39,-13.83 39.52,39.52 0 0 1 13,-9.09 55.46,55.46 0 0 1 21.76,-4 q 22.29,0 35.69,13.84 13.4,13.84 13.38,38.47 0,24.44 -13.28,38.24 -13.28,13.8 -35.48,13.8 Q 125.25,618.7 112,605 98.75,591.3 98.69,567.16 Z m 21,-0.69 q 0,17.13 7.91,26 a 27.21,27.21 0 0 0 40.1,0.07 q 7.8,-8.78 7.81,-26.33 0,-17.34 -7.6,-25.88 -7.6,-8.54 -20.21,-8.53 -12.6,0 -20.3,8.63 -7.7,8.63 -7.72,26.04 z"
       id="path20" />
    <path
       d="M 207.31,617 V 516.08 h 42.89 q 16.17,0 23.5,2.72 a 23.26,23.26 0 0 1 11.74,9.67 29.06,29.06 0 0 1 4.4,15.9 q 0,11.36 -6.67,18.76 -6.67,7.4 -20,9.32 a 47.27,47.27 0 0 1 10.9,8.47 q 4.31,4.62 11.6,16.38 L 298,617 H 273.67 L 258.94,595 Q 251.1,583.24 248.2,580.17 a 15.59,15.59 0 0 0 -6.13,-4.2 q -3.23,-1.14 -10.25,-1.14 h -4.13 V 617 Z m 20.38,-58.24 h 15.07 q 14.67,0 18.31,-1.23 a 11,11 0 0 0 5.71,-4.27 13.11,13.11 0 0 0 2.07,-7.57 12.14,12.14 0 0 0 -2.72,-8.23 12.56,12.56 0 0 0 -7.67,-4 q -2.47,-0.33 -14.87,-0.34 h -15.9 z"
       id="path22" />
    <path
       d="m 326.55,617 v -83.85 h -29.94 v -17.07 h 80.18 v 17.07 H 346.92 V 617 Z"
       id="path24" />
    <path
       d="M 384.1,617 V 516.08 h 20.38 V 617 Z"
       id="path26" />
    <path
       d="M 418.81,617 V 516.08 H 488 v 17.07 H 439.18 V 557 h 42.13 v 17.07 H 439.18 V 617 Z"
       id="path28" />
    <path
       d="M 499.63,617 V 516.08 h 42.89 q 16.15,0 23.5,2.72 a 23.26,23.26 0 0 1 11.74,9.67 29.15,29.15 0 0 1 4.4,15.9 q 0,11.36 -6.67,18.76 -6.67,7.4 -20,9.32 a 47.13,47.13 0 0 1 10.91,8.47 q 4.3,4.62 11.6,16.38 L 590.36,617 H 566 l -14.73,-22 q -7.85,-11.76 -10.74,-14.83 a 15.59,15.59 0 0 0 -6.13,-4.2 c -2.16,-0.76 -5.57,-1.14 -10.26,-1.14 H 520 V 617 Z M 520,558.75 h 15.07 q 14.65,0 18.31,-1.23 a 11,11 0 0 0 5.71,-4.27 13.11,13.11 0 0 0 2.07,-7.57 12.14,12.14 0 0 0 -2.72,-8.23 12.58,12.58 0 0 0 -7.67,-4 c -1.66,-0.22 -6.61,-0.34 -14.88,-0.34 H 520 Z"
       id="path30" />
    <path
       d="m 596,516.08 h 20.38 v 54.65 q 0,13 0.76,16.87 a 16.32,16.32 0 0 0 6.23,9.94 q 4.92,3.76 13.45,3.76 c 5.79,0 10.14,-1.19 13.08,-3.55 a 14,14 0 0 0 5.3,-8.71 q 0.9,-5.14 0.9,-17.13 v -55.83 h 20.37 v 53 q 0,18.18 -1.65,25.67 a 28.37,28.37 0 0 1 -6.09,12.67 30.78,30.78 0 0 1 -11.88,8.23 q -7.43,3 -19.41,3.05 -14.44,0 -21.92,-3.33 A 31.21,31.21 0 0 1 603.72,606.7 27.84,27.84 0 0 1 598,595.52 q -2,-8.67 -2,-25.62 z"
       id="path32" />
    <path
       d="m 715.46,617 v -83.85 h -29.94 v -17.07 h 80.19 v 17.07 H 735.83 V 617 Z"
       id="path34" />
  </g>
  <path
     class="cls-4"
     d="m 361.79882,707.05715 -2.53,-68.43 -124.81,0.07 c 6,16.77 23.47,52.68 23.47,52.68 16.14,14.01 103.87,15.68 103.87,15.68 z"
     id="path92" />
  <path
     class="cls-4"
     d="m 470.52882,697.36715 c 18.62,-8.71 31.25,-44.43 35.67,-58.8 l -127.22,0.06 -5,68.23 c 5.48,1.82 96.55,-9.49 96.55,-9.49 z"
     id="path94" />
  <path
     class="cls-4"
     d="m 486.67882,693.71715 51.76,-11 -52.06,16.48 -19.46,24.37 9.74,-20.41 c -14.64,7 -102.64,11.62 -102.64,11.62 l -7,34.11 -5.81,-34.11 c -6.4,1.22 -95.64,-7.57 -95.64,-7.57 l 5.79,13.7 -15.25,-19.18 h -4.56 c -4.06,-0.63 -28.36,-10 -42.39,-15.51 -4.45,-1.21 -8.11,-2.54 -10,-4 0,0 4.11,1.64 10,4 15.64,4.22 41.79,7 41.79,7 -2,-3.4 -22.88,-39.86 -31.26,-54.5 h -95.63 c 54.58,76.29 143.69,126 244.48,126 100.79,0 189.85,-49.86 244.38,-126.19 h -91.59 c -9.62,16.86 -34.65,55.19 -34.65,55.19 z"
     id="path96" />
  <path
     class="cls-5"
     d="m 378.10882,431.77715 v 28 l 172.66,-0.08 c -0.29,-26.06 -5.77,-51.47 -5.77,-51.47 -38.35,17.09 -166.89,23.55 -166.89,23.55 z"
     id="path98" />
  <path
     class="cls-5"
     d="m 514.19882,315.36715 c 0,0 -75.73,21 -136,22.9 l -0.06,82.85 c 0,0 137.03,-7.38 164.13,-24.12 0,0 -18.62,-74 -28.07,-81.63 z"
     id="path100" />
  <path
     class="cls-5"
     d="m 360.08882,338.79715 c -60.3,-1.8 -133.41,-20.26 -133.41,-20.26 -8.52,7 -24.77,84.37 -24.77,84.37 22.55,12.18 155.18,17.61 155.18,17.61 z"
     id="path102" />
  <path
     class="cls-5"
     d="m 198.70882,413.27715 c -4.56,6.7 -7,46.6 -7,46.6 l 165.43,-0.08 v -28 c -133.46,-4.52 -158.43,-18.52 -158.43,-18.52 z"
     id="path104" />
  <path
     class="cls-4"
     d="m 181.02882,403.23715 c -9.73,-1.27 -36.19,-13.47 -51.46,-20.82 -5.56,-2 -9.8,-3.94 -11.28,-5.53 0,0 4.56,2.3 11.28,5.53 19.37,7 54.35,15 54.35,15 6.1,-20.58 31.79,-83.76 31.79,-83.76 -14.64,-4.05 -28.19,-9.76 -33.23,-12.74 a 10,10 0 0 1 -3.93,-2.48 c 0,0 1.4,1 3.93,2.48 10.64,4.58 36.89,7.26 36.89,7.26 14,-31.17 38,-60.95 49.48,-74.31 a 72.28,72.28 0 0 1 6.51,-7.34 c 0,0 -2.51,2.69 -6.51,7.34 -20.27,25.63 -39.13,76.74 -39.13,76.74 28.64,11.56 131,14.86 131,14.86 l 11,-115.63 0.22,2.61 5.84,113 c 56.05,1.51 135.22,-15.59 135.22,-15.59 -7.34,-22.81 -52.44,-85.86 -52.44,-85.86 23.76,17.67 60.36,83.45 60.36,83.45 9.13,1.78 39,-5.5 39,-5.5 -2.42,3 -34.09,11 -34.09,11 14.3,21.31 29.87,80.39 29.87,80.39 11,0.61 67.6,-16.66 67.6,-16.66 -3.65,5.91 -63.33,27 -63.33,27 1.6,5.89 6.3,46.29 7.39,56 h 99.87 c -16.42,-151.06 -144,-268.59 -298.93,-268.51 -154.93,0.08 -282.449996,117.71 -298.719996,268.77 l 103.839996,-0.06 c -3.07,-4.25 7.61,-56.64 7.61,-56.64 z"
     id="path106" />
</svg>
`,v0=`<?xml version="1.0" encoding="UTF-8"?>
<!-- Generator: Adobe Illustrator 24.3.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg enable-background="new 0 0 975 446" version="1.1" viewBox="0 0 975 446" xml:space="preserve" xmlns="http://www.w3.org/2000/svg">
<style type="text/css">
	.st0{fill:url(#SVGID_1_);}
	.st1{fill:url(#SVGID_2_);}
	.st2{fill:url(#SVGID_3_);}
	.st3{fill:url(#SVGID_4_);}
	.st4{fill:url(#SVGID_5_);}
	.st5{fill:url(#SVGID_6_);}
	.st6{fill:url(#SVGID_7_);}
	.st7{fill:url(#SVGID_8_);}
	.st8{fill:url(#SVGID_9_);}
	.st9{fill:url(#SVGID_10_);}
	.st10{fill:url(#SVGID_11_);}
	.st11{fill:url(#SVGID_12_);}
</style>
<g transform="matrix(1.1056 0 0 1.1056 -51.468 -23.549)">
	<linearGradient id="SVGID_1_" x1="917.69" x2="819.16" y1="-9.603" y2="293.58" gradientUnits="userSpaceOnUse">
		<stop stop-color="#33ACAD" offset="0"/>
		<stop stop-color="#D2D239" offset="1"/>
	</linearGradient>
	<path class="st0" d="m917.1 54.3h-24.7c-19.4 0-35.2 15.7-35.2 35.2v10.4c0 7.9 6.4 14.3 14.3 14.3h10.5c19.4 0 35.2-15.7 35.2-35.2v-24.7z" fill="url(#SVGID_1_)"/>
	
		<linearGradient id="SVGID_2_" x1="447.13" x2="474.3" y1="362.91" y2="217.35" gradientUnits="userSpaceOnUse">
			<stop stop-color="#33ACAD" offset="0"/>
			<stop stop-color="#D2D239" offset="1"/>
		</linearGradient>
		<path class="st1" d="m481.6 293.8h-13.9c-12.7 0-23-10.3-23-23v-110.5c0-12.7 10.3-23 23-23h13.9c12.7 0 23 10.3 23 23v110.5c0 12.7-10.3 23-23 23z" fill="url(#SVGID_2_)"/>
		<linearGradient id="SVGID_3_" x1="286.43" x2="470" y1="25.751" y2="302.38" gradientUnits="userSpaceOnUse">
			<stop stop-color="#33ACAD" offset="0"/>
			<stop stop-color="#D2D239" offset="1"/>
		</linearGradient>
		<path class="st2" d="m384.8 54.3c-66.1 0-119.8 53.6-119.8 119.8 0 66.1 53.6 119.8 119.8 119.8 66.1 0 119.8-53.6 119.8-119.8s-53.6-119.8-119.8-119.8zm0 179.6c-33.1 0-59.9-26.8-59.9-59.9s26.8-59.9 59.9-59.9 59.9 26.8 59.9 59.9-26.8 59.9-59.9 59.9z" fill="url(#SVGID_3_)"/>
	
	<linearGradient id="SVGID_4_" x1="963.6" x2="845.11" y1="-29.017" y2="335.56" gradientUnits="userSpaceOnUse">
		<stop stop-color="#33ACAD" offset="0"/>
		<stop stop-color="#D2D239" offset="1"/>
	</linearGradient>
	<path class="st3" d="m894 293.8h-13.9c-12.7 0-23-10.3-23-23v-128.4c0-12.7 10.3-23 23-23h13.9c12.7 0 23 10.3 23 23v128.4c0 12.7-10.3 23-23 23z" fill="url(#SVGID_4_)"/>
	
		<linearGradient id="SVGID_5_" x1="112.47" x2="261.62" y1="447.53" y2="23.025" gradientUnits="userSpaceOnUse">
			<stop stop-color="#33ACAD" offset="0"/>
			<stop stop-color="#D2D239" offset="1"/>
		</linearGradient>
		<path class="st4" d="m248.2 124.2h-48c-3.3 0-5.9 2.6-5.9 5.9v163.7c-0.1 21-17.1 37.9-38 37.9-15.1 0-28.1-8.8-34.3-21.5-4.8-9.9-14.5-16.5-25.5-16.5h-2.8c-21 0-35.3 21.7-26.6 40.8 15.5 33.8 49.6 57.3 89.2 57.3 52.7 0 95.5-41.5 97.8-93.6 0.1-0.4 0.1-0.7 0.1-1.1v-167c0-3.2-2.7-5.9-6-5.9z" fill="url(#SVGID_5_)"/>
		
			<linearGradient id="SVGID_6_" x1="363.42" x2="-1.1682" y1="300.01" y2="50.15" gradientUnits="userSpaceOnUse">
				<stop stop-color="#33ACAD" offset="0"/>
				<stop stop-color="#D2D239" offset="1"/>
			</linearGradient>
			<path class="st5" d="m224.2 54.3c-16.5 0-29.9 13.4-29.9 29.9v111.5h-0.2c0 21-17 38-38 38s-38-17-38-38h-60.1c0 54.2 43.9 98.1 98.1 98.1 50.2 0 91.6-37.8 97.4-86.5h0.7v-123.1c0-16.5-13.4-29.9-30-29.9z" fill="url(#SVGID_6_)"/>
			<linearGradient id="SVGID_7_" x1="53.995" x2="131.29" y1="39.357" y2="308" gradientUnits="userSpaceOnUse">
				<stop stop-color="#33ACAD" offset="0"/>
				<stop stop-color="#D2D239" offset="1"/>
			</linearGradient>
			<path class="st6" d="m118 195.7-0.2-87.1c0-0.4 0.1-0.7 0.1-1.1s0-0.8-0.1-1.2v-1.2h-0.1c-1.2-15.4-14.1-27.6-29.8-27.6-16.6 0-30 13.4-30 30v0.1 88.1c-3 52.1 48.7 100 98.1 98.1-51.5 0.3-38-98.1-38-98.1z" fill="url(#SVGID_7_)"/>
		
	
	
		<linearGradient id="SVGID_8_" x1="812" x2="817.76" y1="349.86" y2="188.73" gradientUnits="userSpaceOnUse">
			<stop stop-color="#33ACAD" offset="0"/>
			<stop stop-color="#D2D239" offset="1"/>
		</linearGradient>
		<path class="st7" d="m823.8 293.5h-13.9c-12.7 0-23-10.3-23-23v-110.4c0-12.7 10.3-23 23-23h13.9c12.7 0 23 10.3 23 23v110.5c-0.1 12.7-10.3 22.9-23 22.9z" fill="url(#SVGID_8_)"/>
		
			
				<linearGradient id="SVGID_9_" x1="929.76" x2="676.34" y1="45.023" y2="285.05" gradientUnits="userSpaceOnUse">
					<stop stop-color="#33ACAD" offset="0"/>
					<stop stop-color="#D2D239" offset="1"/>
				</linearGradient>
				<path class="st8" d="m846.7 102.3c-0.2-16.3-13.5-29.5-29.9-29.5s-29.7 13.2-29.9 29.5v93.2h-0.2c0 21-17 38-38 38s-38-17-38-38h-60.1c0 54.2 43.9 98.1 98.1 98.1 51.1 0 93.1-39.1 97.7-89h0.4z" fill="url(#SVGID_9_)"/>
			
			
				<linearGradient id="SVGID_10_" x1="711.94" x2="552.27" y1="129.45" y2="270.95" gradientUnits="userSpaceOnUse">
					<stop stop-color="#33ACAD" offset="0"/>
					<stop stop-color="#D2D239" offset="1"/>
				</linearGradient>
				<path class="st9" d="m650.6 195.5c0 21-17 38-38 38s-38-17-38-38h-60.1c0 54.2 43.9 98.1 98.1 98.1s98.1-43.9 98.1-98.1z" fill="url(#SVGID_10_)"/>
			
		
	
	<linearGradient id="SVGID_11_" x1="514.46" x2="612.68" y1="202.66" y2="202.66" gradientUnits="userSpaceOnUse">
		<stop stop-color="#33ACAD" offset="0"/>
		<stop stop-color="#D2D239" offset="1"/>
	</linearGradient>
	<path class="st10" d="m574.6 194.4-0.2-52.1v-0.6c0-16.5-13.4-30-30-30-16.5 0-30 13.4-30 30v0.6 52.1c-3 52.6 45.6 101.4 98.1 99.1-51.4 0.3-37.9-99.1-37.9-99.1z" fill="url(#SVGID_11_)"/>
	<linearGradient id="SVGID_12_" x1="773.55" x2="679.33" y1="127.23" y2="223.09" gradientUnits="userSpaceOnUse">
		<stop stop-color="#33ACAD" offset="0"/>
		<stop stop-color="#D2D239" offset="1"/>
	</linearGradient>
	<path class="st11" d="m710.9 194.4-0.2-69.9c0-0.5 0.1-0.9 0.1-1.4 0-16.6-13.4-30-30-30-16.4 0-29.6 13.1-29.9 29.4v71.9c-3 52.6 44.6 101.4 98.1 99.1-51.6 0.3-38.1-99.1-38.1-99.1z" fill="url(#SVGID_12_)"/>
</g>
</svg>
`,w0='<svg xmlns="http://www.w3.org/2000/svg" width="120" height="60"><path d="M76.082 21.118c-4.79.023-8.692 3.96-8.67 8.862s3.963 8.802 8.753 8.78 8.693-3.96 8.67-8.86-3.963-8.803-8.755-8.78zm.066 14.047c-1.358.008-2.663-.525-3.628-1.48s-1.5-2.256-1.515-3.614.525-2.663 1.48-3.628 2.256-1.5 3.614-1.515 2.663.525 3.628 1.48 1.5 2.256 1.515 3.614c.014 2.725-2.37 5.13-5.094 5.144zm19.34-9.892c-2.505.012-4.456 2.09-4.444 4.595l.04 8.385-3.812.018-.077-16.663 3.812-.018.013 2.613s1.62-2.62 4.888-2.635l1.09-.006.018 3.702zM57.462 21.75l2.886 11.422 2.996-11.45 3.812-.017L62.44 38.4l-3.702.017-2.994-11.638-2.886 11.665-3.703.017-4.978-16.64 3.702-.017 3.32 11.42 2.67-11.448zm50.675 7.386c2.605-1.536 4.445-4.377 4.43-7.644l-3.812.018c.014 2.832-2.264 5.13-4.986 5.14l-.545.002-.06-13.177-3.812.018.117 24.72 3.81-.017-.036-7.84.435-.002c.436-.002.873.214.984.54l5.37 7.27 4.465-.02z" fill="#4b4b4b"/><path d="M35.353 21.31c-4.137.02-7.283 2.757-8.46 7.118-1.975-3.04-3.516-6.517-4.4-9.453l-4.355.02.054 11.543a4.14 4.14 0 0 1-4.119 4.158 4.14 4.14 0 0 1-4.158-4.119L9.86 19.034l-4.357.02.054 11.543c.023 4.79 3.85 8.586 8.534 8.563s8.478-3.852 8.456-8.643l-.01-1.96c.878 1.737 1.976 3.583 3.183 5.212l-2.663 12.753 4.464-.02 1.92-9.266c1.747 1.082 3.7 1.725 5.996 1.714 4.792-.023 8.695-3.96 8.67-8.97a8.74 8.74 0 0 0-8.753-8.671zm.062 13.177c-1.742.008-3.487-.746-4.908-1.938l.427-1.743v-.1c.32-1.854 1.282-5.016 4.55-5.03A4.37 4.37 0 0 1 39.861 30c-.098 2.505-2.157 4.475-4.445 4.486z" fill="#6fda44"/></svg>',y0=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Created with Inkscape (http://www.inkscape.org/) -->

<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:xlink="http://www.w3.org/1999/xlink"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="194.77385mm"
   height="194.91034mm"
   viewBox="0 0 194.77385 194.91034"
   version="1.1"
   id="svg3719"
   inkscape:version="0.92.4 (33fec40, 2019-01-16)"
   sodipodi:docname="logounicore2.svg"
   inkscape:export-filename="/home/ivanjoz/Imágenes/logounicore2.svg.png"
   inkscape:export-xdpi="260.63278"
   inkscape:export-ydpi="260.63278">
  <defs
     id="defs3713">
    <linearGradient
       inkscape:collect="always"
       id="linearGradient4666">
      <stop
         style="stop-color:#6469ee;stop-opacity:1"
         offset="0"
         id="stop4662" />
      <stop
         style="stop-color:#c56da1;stop-opacity:1"
         offset="1"
         id="stop4664" />
    </linearGradient>
    <linearGradient
       id="linearGradient4624"
       inkscape:collect="always">
      <stop
         id="stop4620"
         offset="0"
         style="stop-color:#ff3554;stop-opacity:1" />
      <stop
         id="stop4622"
         offset="1"
         style="stop-color:#a093ff;stop-opacity:1" />
    </linearGradient>
    <linearGradient
       id="linearGradient4612"
       inkscape:collect="always">
      <stop
         id="stop4604"
         offset="0"
         style="stop-color:#ec7e78;stop-opacity:1" />
      <stop
         style="stop-color:#6f51d5;stop-opacity:1"
         offset="0.4509545"
         id="stop4606" />
      <stop
         id="stop4608"
         offset="0.77218282"
         style="stop-color:#4fa3ff;stop-opacity:1" />
      <stop
         id="stop4610"
         offset="1"
         style="stop-color:#00cbff;stop-opacity:1" />
    </linearGradient>
    <linearGradient
       inkscape:collect="always"
       id="linearGradient4554">
      <stop
         style="stop-color:#00c4a3;stop-opacity:1"
         offset="0"
         id="stop4548" />
      <stop
         id="stop4550"
         offset="0.67359167"
         style="stop-color:#6d74e8;stop-opacity:1" />
      <stop
         style="stop-color:#a470b8;stop-opacity:1"
         offset="1"
         id="stop4552" />
    </linearGradient>
    <linearGradient
       gradientUnits="userSpaceOnUse"
       y2="144.27525"
       x2="83.341652"
       y1="222.70741"
       x1="134.18935"
       id="linearGradient1288-2"
       xlink:href="#linearGradient4624"
       inkscape:collect="always"
       gradientTransform="matrix(1.0013698,0,0,1.0013696,17.538794,-90.483456)" />
    <linearGradient
       y2="425.25659"
       x2="387.23022"
       y1="434.60245"
       x1="667.71747"
       gradientTransform="matrix(0.98956991,0.15393996,-0.15410882,0.98848525,-336.8655,-369.78032)"
       gradientUnits="userSpaceOnUse"
       id="linearGradient972"
       xlink:href="#linearGradient4612"
       inkscape:collect="always" />
    <linearGradient
       y2="441.40515"
       x2="614.85541"
       y1="452.27588"
       x1="546.77234"
       gradientTransform="matrix(0.98944329,0.15408913,-0.1540891,0.98944309,-336.82063,-370.25219)"
       gradientUnits="userSpaceOnUse"
       id="linearGradient974"
       xlink:href="#linearGradient4666"
       inkscape:collect="always" />
    <linearGradient
       y2="412.80106"
       x2="387.6008"
       y1="330.6091"
       x1="642.06726"
       gradientTransform="matrix(0.98956991,0.15393996,-0.15410882,0.98848525,-337.34104,-369.80751)"
       gradientUnits="userSpaceOnUse"
       id="linearGradient990"
       xlink:href="#linearGradient4554"
       inkscape:collect="always" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient4624"
       id="linearGradient4371"
       x1="31.417019"
       y1="155.67203"
       x2="74.273422"
       y2="197.71597"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(24.895461,-22.238536)" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient4624"
       id="linearGradient4636"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(129.55754,-131.11308)"
       x1="74.2118"
       y1="186.09717"
       x2="18.413765"
       y2="157.94896" />
  </defs>
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="0.49497475"
     inkscape:cx="-528.72351"
     inkscape:cy="543.95051"
     inkscape:document-units="mm"
     inkscape:current-layer="layer1-3"
     showgrid="false"
     inkscape:window-width="1920"
     inkscape:window-height="1011"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="1"
     fit-margin-top="0"
     fit-margin-left="0"
     fit-margin-right="0"
     fit-margin-bottom="0" />
  <metadata
     id="metadata3716">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title />
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:label="Capa 1"
     inkscape:groupmode="layer"
     id="layer1"
     transform="translate(-7.6327575,-23.04142)">
    <g
       transform="translate(-6.1439408,3.278603)"
       id="layer1-3"
       inkscape:label="Capa 1">
      <path
         style="fill:#ffffff;fill-opacity:1;stroke-width:0.75087291"
         d="m 137.69811,183.00445 c 9.28365,-3.55668 15.32743,-7.81544 27.18603,-19.15661 4.46079,-4.26617 10.05665,-8.88632 12.43523,-10.26696 2.51859,-1.46191 6.17818,-3.4972 9.56293,-4.45137 1.53568,-0.43288 4.52326,-0.91117 4.75623,-0.54424 0.40046,0.47095 -0.31366,2.22106 -1.93473,4.60863 -10.28301,15.33947 -25.64524,25.05402 -48.31201,30.05127 -8.19284,1.80612 -8.91398,1.75913 -3.69351,-0.24266 z"
         id="path852-0-0-6-9-6-2-1"
         inkscape:connector-curvature="0"
         sodipodi:nodetypes="cccaccccc" />
      <g
         id="g1205-3"
         transform="matrix(0.98546555,0.17776141,-0.17776137,0.98546536,31.775778,-86.679653)">
        <path
           inkscape:connector-curvature="0"
           style="fill:#ffffff;fill-opacity:1;stroke:none;stroke-width:0.77257925;stroke-opacity:1"
           d="m 17.131638,192.94951 a 97.485504,97.366563 7.6000001e-6 0 0 97.247682,90.66065 97.485504,97.366563 7.6000001e-6 0 0 96.03913,-81.30694 c -1.08561,-1.78225 -4.84254,0.28322 -6.08432,3.04646 -3.72926,8.29854 -9.73648,18.36683 -17.15141,25.39743 -8.48133,8.04178 -13.61094,12.06928 -30.0658,18.0587 -24.08564,8.76689 -51.90233,6.69484 -60.956386,-3.45141 -3.933481,-4.40794 -4.00503,-9.87352 0.56783,-11.96062 2.557919,-1.16747 2.659239,-1.69327 16.859706,1.43336 10.37029,2.28335 22.55497,2.90119 28.50294,1.30163 8.16191,-2.1949 15.56472,-7.74424 19.08197,-14.30408 1.04659,-1.95205 1.77315,-3.66047 1.61453,-3.79695 -0.15866,-0.13641 -3.68518,0.37333 -6.86624,0.61363 -5.18705,0.79669 -14.12304,0.10095 -19.28727,-1.27324 -1.68373,-0.44804 -10.47066,-4.3136 -21.51722,-8.54174 -22.116625,-8.46523 -24.049245,-8.95777 -31.940946,-8.76178 -6.644859,0.16533 -12.491791,2.37204 -23.051629,8.70084 -13.352053,8.00216 -19.839537,8.5766 -26.796847,5.40282 -3.83409,-1.96287 -11.50342,-9.40339 -16.19572,-21.21876 z m 46.498357,38.03211 c 6.404829,-0.15335 11.719157,4.8244 11.87024,11.11816 0.151098,6.29377 -4.91826,11.52001 -11.323093,11.67343 -6.404819,0.15337 -11.71965,-4.82442 -11.870737,-11.11816 -0.151083,-6.29377 4.918768,-11.52004 11.32359,-11.67343 z"
           id="path854-6-3-3-2-6-3-1" />
      </g>
      <ellipse
         transform="matrix(0.9880853,0.15390724,-0.15384942,0.98809431,0,0)"
         cy="97.271835"
         cx="130.49847"
         id="path877-2-0-0-6-2-2"
         style="opacity:1;fill:url(#linearGradient1288-2);fill-opacity:1;stroke:none;stroke-width:0.63988703;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
         rx="14.492359"
         ry="14.53111" />
      <path
         id="path854-6-3-3-2-6-4"
         d="m 14.359524,106.52108 a 97.629741,97.407319 5.3903034 0 0 79.728482,106.5266 97.629741,97.407319 5.3903034 0 0 109.110454,-62.99209 c -0.75312,-1.94743 -4.82312,-0.58115 -6.53827,1.91876 -5.15088,7.50773 -12.86152,16.35326 -21.41955,21.95816 -9.78882,6.41103 -15.56054,9.46518 -32.84316,12.43963 -25.29721,4.35375 -52.344734,-2.62616 -59.464492,-14.22316 -3.093144,-5.03822 -2.191971,-10.43184 2.686056,-11.67453 2.728623,-0.69512 2.921962,-1.19479 16.361946,4.40526 9.81494,4.08964 21.71421,6.86178 27.86087,6.3433 8.43453,-0.71144 16.71727,-4.86017 21.35007,-10.69378 1.37856,-1.73596 2.39836,-3.28888 2.26631,-3.45143 -0.13213,-0.16246 -3.69847,-0.28689 -6.87642,-0.61523 -5.25394,-0.13682 -13.9375,-2.40873 -18.78302,-4.67874 -1.5798,-0.74011 -9.55289,-6.10627 -19.68859,-12.23067 -20.292983,-12.26178 -22.11019,-13.08991 -29.923029,-14.29844 -6.578512,-1.01728 -12.733514,0.1169 -24.266367,4.47236 -14.582325,5.50703 -21.078463,4.92047 -27.371282,0.5603 -3.42988,-2.61336 -9.665901,-11.30063 -12.190008,-23.7663 z m 39.066885,45.70066 c 6.339812,0.98645 10.692606,6.83087 9.72258,13.05398 -0.97001,6.22312 -6.895472,10.46815 -13.235294,9.48176 -6.339806,-0.98643 -10.693084,-6.83098 -9.72307,-13.05407 0.970029,-6.22312 6.895977,-10.46809 13.235784,-9.48167 z"
         style="opacity:1;fill:url(#linearGradient972);fill-opacity:1;stroke:none;stroke-width:0.30028468;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
         inkscape:connector-curvature="0" />
      <path
         style="fill:url(#linearGradient974);fill-opacity:1;stroke:none;stroke-width:0.30041093;stroke-miterlimit:4;stroke-dasharray:none"
         d="m 137.69811,183.00445 c 9.28365,-3.55668 15.32743,-7.81544 27.18603,-19.15661 4.46079,-4.26617 10.05665,-8.88632 12.43523,-10.26696 2.51859,-1.46191 6.17818,-3.4972 9.56293,-4.45137 1.53568,-0.43288 4.52326,-0.91117 4.75623,-0.54424 0.40046,0.47095 -0.31366,2.22106 -1.93473,4.60863 -10.28301,15.33947 -25.64523,25.05402 -48.31201,30.05127 -8.19284,1.80612 -8.91398,1.75913 -3.69351,-0.24266 z"
         id="path852-0-0-6-9-6-5"
         inkscape:connector-curvature="0"
         sodipodi:nodetypes="cccaccccc" />
      <path
         id="path848-5-0-0-7-5-4"
         d="M 128.23294,21.303334 A 97.629736,97.407317 5.3902384 0 0 17.481484,89.101782 c 2.186548,9.722548 5.500952,17.901968 8.02357,22.188588 3.437795,5.75443 6.01433,5.09231 6.924233,-0.65205 1.461411,-7.25157 2.926576,-13.006899 6.898974,-21.644668 11.654284,-23.958547 30.731552,-39.636353 50.222388,-47.206564 22.752461,-8.837086 48.082071,-6.951738 67.679681,5.037677 7.12348,4.357986 12.81347,8.946325 17.26173,14.24859 a 11.617392,11.404012 8.4268543 0 1 8.65298,12.833434 11.617392,11.404012 8.4268543 0 1 -13.23539,9.482278 11.617392,11.404012 8.4268543 0 1 -9.72309,-13.054086 11.617392,11.404012 8.4268543 0 1 9.43991,-9.442072 c -20.41082,-20.707045 -60.29659,-18.64158 -65.98382,5.490977 -1.91733,8.13574 -0.37889,14.341367 4.98327,20.101273 5.26394,5.654399 15.72683,9.568379 42.76941,15.999371 17.20118,4.09061 25.72075,6.87684 33.28299,10.88499 9.73447,5.15943 17.99298,12.73941 20.83957,20.22534 l 1.05888,2.71323 a 97.629736,97.407317 5.3902384 0 0 0.42689,-1.8338 97.629736,97.407317 5.3902384 0 0 -78.77077,-113.170965 z"
         style="fill:url(#linearGradient990);fill-opacity:1;stroke:none;stroke-width:0.2001898;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
         inkscape:connector-curvature="0" />
      <ellipse
         transform="matrix(0.9880853,0.15390724,-0.15384942,0.98809431,0,0)"
         ry="5.792985"
         rx="5.8000555"
         cy="153.68568"
         cx="76.250954"
         id="path893-1-3-0-0"
         style="opacity:1;fill:url(#linearGradient4371);fill-opacity:1;stroke:none;stroke-width:1.03775239;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <ellipse
         transform="matrix(0.9880853,0.15390724,-0.15384942,0.98809431,0,0)"
         ry="5.792985"
         rx="5.8000555"
         cy="44.811138"
         cx="180.91306"
         id="path893-1-3-0-0-1"
         style="opacity:1;fill:url(#linearGradient4636);fill-opacity:1;stroke:none;stroke-width:1.03775239;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
    </g>
  </g>
</svg>
`,x0=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Created with Inkscape (http://www.inkscape.org/) -->

<svg
   width="32.577118mm"
   height="32.577824mm"
   version="1.1"
   viewBox="0 0 32.577116 32.577825"
   id="svg22"
   sodipodi:docname="equom-logo.svg"
   inkscape:version="1.3.1 (91b66b0783, 2023-11-16)"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:dc="http://purl.org/dc/elements/1.1/">
  <defs
     id="defs22" />
  <sodipodi:namedview
     id="namedview22"
     pagecolor="#ffffff"
     bordercolor="#000000"
     borderopacity="0.25"
     inkscape:showpageshadow="2"
     inkscape:pageopacity="0.0"
     inkscape:pagecheckerboard="0"
     inkscape:deskcolor="#d1d1d1"
     inkscape:document-units="mm"
     inkscape:zoom="1.1057285"
     inkscape:cx="37.079628"
     inkscape:cy="186.30252"
     inkscape:window-width="1920"
     inkscape:window-height="1008"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="1"
     inkscape:current-layer="g22" />
  <metadata
     id="metadata1">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     transform="translate(-74.237,-73.562736)"
     id="g22">
    <g
       transform="matrix(0.35278,0,0,-0.35278,74.237,89.852)"
       id="g6">
      <path
         d="M 0,0 C 0,25.461 20.715,46.174 46.172,46.174 71.631,46.174 92.344,25.461 92.344,0 92.344,-25.459 71.631,-46.172 46.172,-46.172 20.715,-46.172 0,-25.459 0,0"
         fill="#1c202d"
         id="path6" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,82.963,89.852)"
       id="g7">
      <path
         d="m 0,0 h -1.078 c 0,4.979 1.592,9.697 4.601,13.645 l 0.86,-0.656 C 1.516,9.232 0,4.74 0,0"
         fill="#ffffff"
         id="path7" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,98.469,89.852)"
       id="g8">
      <path
         d="m 0,0 h -1.078 c 0,8.522 -5.047,16.236 -12.858,19.652 l 0.434,0.99 C -5.299,17.054 0,8.951 0,0"
         fill="#ffffff"
         id="path8" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,79.968,89.852)"
       id="g9">
      <path
         d="m 0,0 h -1.078 c 0,13.778 9.244,26.04 22.478,29.818 l 0.295,-1.036 C 8.924,25.135 0,13.301 0,0"
         fill="#ffffff"
         id="path9" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,101.46,89.852)"
       id="g10">
      <path
         d="m 0,0 h -1.08 c 0,8.522 -3.652,16.667 -10.018,22.343 l 0.719,0.805 C -3.783,17.268 0,8.829 0,0"
         fill="#ffffff"
         id="path10" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,77.151,89.852)"
       id="g11">
      <path
         d="m 0,0 h -1.078 c 0,11.606 5.119,22.527 14.043,29.965 l 0.691,-0.828 C 4.979,21.903 0,11.284 0,0"
         fill="#ffffff"
         id="path11" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,104.28,89.852)"
       id="g12">
      <path
         d="m 0,0 h -1.08 c 0,16.78 -10.772,31.352 -26.803,36.259 l 0.315,1.03 C -11.08,32.245 0,17.259 0,0"
         fill="#ffffff"
         id="path12" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,82.39,78.534)"
       id="g13">
      <path
         d="m 0,0 c -0.758,0 -1.375,-0.618 -1.375,-1.375 0,-0.758 0.617,-1.377 1.375,-1.377 0.76,0 1.377,0.619 1.377,1.377 C 1.377,-0.618 0.76,0 0,0 m 0,-3.829 c -1.352,0 -2.453,1.1 -2.453,2.454 0,1.354 1.101,2.454 2.453,2.454 1.354,0 2.455,-1.1 2.455,-2.454 0,-1.354 -1.101,-2.454 -2.455,-2.454"
         fill="#ffffff"
         id="path13" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,88.245,78.834)"
       id="g14">
      <path
         d="m 0,0 c -0.758,0 -1.375,-0.617 -1.375,-1.377 0,-0.758 0.617,-1.373 1.375,-1.373 0.758,0 1.375,0.615 1.375,1.373 C 1.375,-0.617 0.758,0 0,0 m 0,-3.828 c -1.354,0 -2.455,1.099 -2.455,2.451 0,1.356 1.101,2.457 2.455,2.457 1.355,0 2.453,-1.101 2.453,-2.457 0,-1.352 -1.098,-2.451 -2.453,-2.451"
         fill="#ffffff"
         id="path14" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,84.762,84.154)"
       id="g15">
      <path
         d="m 0,0 c -0.758,0 -1.373,-0.615 -1.373,-1.373 0,-0.759 0.615,-1.377 1.373,-1.377 0.76,0 1.377,0.618 1.377,1.377 C 1.377,-0.615 0.76,0 0,0 m 0,-3.829 c -1.354,0 -2.455,1.1 -2.455,2.456 0,1.352 1.101,2.452 2.455,2.452 1.354,0 2.455,-1.1 2.455,-2.452 0,-1.356 -1.101,-2.456 -2.455,-2.456"
         fill="#ffffff"
         id="path15" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,93.102,82.092)"
       id="g16">
      <path
         d="m 0,0 c -0.758,0 -1.377,-0.618 -1.377,-1.376 0,-0.758 0.619,-1.374 1.377,-1.374 0.758,0 1.377,0.616 1.377,1.374 C 1.377,-0.618 0.758,0 0,0 m 0,-3.829 c -1.354,0 -2.455,1.1 -2.455,2.453 0,1.355 1.101,2.455 2.455,2.455 1.354,0 2.455,-1.1 2.455,-2.455 0,-1.353 -1.101,-2.453 -2.455,-2.453"
         fill="#ffffff"
         id="path16" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,97.169,80.962)"
       id="g17">
      <path
         d="m 0,0 c -0.758,0 -1.373,-0.616 -1.373,-1.373 0,-0.76 0.615,-1.378 1.373,-1.378 0.76,0 1.377,0.618 1.377,1.378 C 1.377,-0.616 0.76,0 0,0 m 0,-3.829 c -1.352,0 -2.451,1.101 -2.451,2.456 0,1.353 1.099,2.453 2.451,2.453 1.354,0 2.457,-1.1 2.457,-2.453 0,-1.355 -1.103,-2.456 -2.457,-2.456"
         fill="#ffffff"
         id="path17" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,93.912,76.27)"
       id="g18">
      <path
         d="m 0,0 c -0.758,0 -1.377,-0.617 -1.377,-1.375 0,-0.759 0.619,-1.377 1.377,-1.377 0.756,0 1.373,0.618 1.373,1.377 C 1.373,-0.617 0.756,0 0,0 m 0,-3.83 c -1.354,0 -2.457,1.101 -2.457,2.455 0,1.354 1.103,2.454 2.457,2.454 1.352,0 2.451,-1.1 2.451,-2.454 C 2.451,-2.729 1.352,-3.83 0,-3.83"
         fill="#ffffff"
         id="path18" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,78.999,89.852)"
       id="g19">
      <path
         d="m 0,0 h 4.695 c 0,-15.427 12.553,-27.978 27.979,-27.978 15.428,0 27.976,12.551 27.976,27.978 h 4.7 C 65.35,-18.018 50.693,-32.676 32.674,-32.676 14.656,-32.676 0,-18.018 0,0"
         fill="#069494"
         id="path19" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,76.149,89.852)"
       id="g20">
      <path
         d="m 0,0 h 4.697 c 0,-19.881 16.174,-36.054 36.055,-36.054 19.883,0 36.055,16.173 36.055,36.054 h 4.697 c 0,-22.472 -18.279,-40.751 -40.752,-40.751 C 18.281,-40.751 0,-22.472 0,0"
         fill="#004b8d"
         id="path20" />
    </g>
    <g
       transform="matrix(0.35278,0,0,-0.35278,81.801,89.852)"
       id="g21">
      <path
         d="m 0,0 h 4.697 c 0,-11.044 8.987,-20.032 20.033,-20.032 11.045,0 20.032,8.988 20.032,20.032 h 4.697 C 49.459,-13.635 38.367,-24.73 24.73,-24.73 11.096,-24.73 0,-13.635 0,0"
         fill="#14a751"
         id="path21" />
    </g>
  </g>
</svg>
`,k0=`<?xml version="1.0" encoding="UTF-8"?>
<svg width="92.09" height="92" data-name="Layer 1" version="1.1" viewBox="0 0 92.09 92" xmlns="http://www.w3.org/2000/svg">
 <path d="m46.25 54.01-14.32 13.1c-1.05-7.83-7.78-13.9-15.89-13.9-8.84 0-16.04 7.19-16.04 16.04v21.75c0 0.55 0.45 1 1 1h29c0.55 0 1-0.45 1-1s-0.45-1-1-1h-8.18v-13.29c0-0.55-0.45-1-1-1s-1 0.45-1 1v13.29h-7.89v-13.29c0-0.55-0.45-1-1-1s-1 0.45-1 1v13.29h-7.93v-20.75c0-7.74 6.3-14.04 14.04-14.04s14.04 6.3 14.04 14.04c0 0.4 0.23 0.76 0.6 0.92 0.36 0.16 0.79 0.09 1.08-0.18l15.86-14.5c0.41-0.37 0.44-1 0.06-1.41s-1.01-0.44-1.41-0.06z"/>
 <path d="m16.04 50.27c6.53 0 11.84-5.31 11.84-11.84s-5.31-11.84-11.84-11.84-11.84 5.31-11.84 11.84 5.31 11.84 11.84 11.84zm0-21.67c5.42 0 9.84 4.41 9.84 9.84s-4.41 9.84-9.84 9.84-9.84-4.41-9.84-9.84 4.41-9.84 9.84-9.84z"/>
 <path d="m31.15 28.46c0.16 0.09 0.33 0.14 0.5 0.14 0.27 0 0.53-0.11 0.72-0.31l8.81-9.21c0.19-0.2 0.45-0.31 0.72-0.31h25.2c1.65 0 3-1.35 3-3v-12.77c0-1.65-1.35-3-3-3h-30.46c-1.65 0-3 1.35-3 3v14.48c0 0.1-0.01 0.2-0.04 0.29l-2.9 9.54c-0.13 0.44 0.05 0.92 0.45 1.15zm4.36-10.11c0.09-0.28 0.13-0.58 0.13-0.87v-14.48c0-0.55 0.45-1 1-1h30.46c0.55 0 1 0.45 1 1v12.78c0 0.55-0.45 1-1 1h-25.2c-0.81 0-1.6 0.34-2.17 0.93l-5.91 6.18 1.68-5.53z"/>
 <path d="m63.6 38.44c0 6.53 5.31 11.84 11.84 11.84s11.84-5.31 11.84-11.84-5.31-11.84-11.84-11.84-11.84 5.31-11.84 11.84zm11.84-9.84c5.42 0 9.84 4.41 9.84 9.84s-4.41 9.84-9.84 9.84-9.84-4.41-9.84-9.84 4.41-9.84 9.84-9.84z"/>
 <path d="m75.44 53.21c-9.18 0-16.66 7.47-16.66 16.65v21.13c0 0.55 0.45 1 1 1h31.31c0.55 0 1-0.45 1-1v-21.13c0-9.18-7.47-16.65-16.65-16.65zm14.65 36.79h-8.06v-13.29c0-0.55-0.45-1-1-1s-1 0.45-1 1v13.29h-8.32v-13.29c0-0.55-0.45-1-1-1s-1 0.45-1 1v13.29h-8.94v-20.13c0-8.08 6.57-14.65 14.66-14.65s14.65 6.57 14.65 14.65v20.13z"/>
 <path d="m38.581 5.7106h27.08c0.55 0 1-0.45 1-1s-0.45-1-1-1h-27.08c-0.55 0-1 0.45-1 1s0.45 1 1 1z"/>
 <path d="m38.581 10.131h27.08c0.55 0 1-0.45 1-1s-0.45-1-1-1h-27.08c-0.55 0-1 0.45-1 1s0.45 1 1 1z"/>
 <path d="m66.661 13.551c0-0.55-0.45-1-1-1h-27.08c-0.55 0-1 0.45-1 1s0.45 1 1 1h27.08c0.55 0 1-0.45 1-1z"/>
</svg>
`,u0=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
   version="1.1"
   x="0px"
   y="0px"
   viewBox="0 0 89.199997 72.800003"
   xml:space="preserve"
   id="svg7"
   sodipodi:docname="noun-cloud-technology-5719631.svg"
   width="89.199997"
   height="72.800003"
   inkscape:version="1.3.1 (91b66b0783, 2023-11-16)"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg"><defs
     id="defs7" /><sodipodi:namedview
     id="namedview7"
     pagecolor="#ffffff"
     bordercolor="#000000"
     borderopacity="0.25"
     inkscape:showpageshadow="2"
     inkscape:pageopacity="0.0"
     inkscape:pagecheckerboard="0"
     inkscape:deskcolor="#d1d1d1"
     inkscape:zoom="6.432"
     inkscape:cx="44.620647"
     inkscape:cy="30.317164"
     inkscape:window-width="1920"
     inkscape:window-height="1008"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="1"
     inkscape:current-layer="svg7" /><g
     id="g6"
     transform="translate(-5.4,-13.6)"><path
       d="m 65,77.4 v -5.3 c 0,-0.3 -0.1,-0.6 -0.4,-0.9 L 55.4,62 V 43.1 c 0,-0.7 -0.5,-1.2 -1.2,-1.2 -0.7,0 -1.2,0.6 -1.2,1.2 v 19.3 c 0,0.3 0.1,0.6 0.4,0.9 l 9.3,9.3 v 4.8 c -1.9,0.5 -3.3,2.3 -3.3,4.4 0,2.5 2,4.6 4.6,4.6 2.6,0 4.6,-2 4.6,-4.6 C 68.4,79.7 67,78 65,77.4 Z m -1.2,6.5 c -1.2,0 -2.1,-1 -2.1,-2.1 0,-1.1 1,-2.1 2.1,-2.1 1.2,0 2.1,1 2.1,2.1 0,1.1 -0.9,2.1 -2.1,2.1 z"
       id="path1" /><path
       d="m 53.1,77.2 c -2.1,0 -3.9,1.4 -4.4,3.4 H 35 V 66.8 c 1.9,-0.5 3.3,-2.3 3.3,-4.4 0,-2.5 -2,-4.6 -4.6,-4.6 -2.5,0 -4.6,2 -4.6,4.6 0,2.1 1.4,3.8 3.3,4.4 v 15 c 0,0.7 0.5,1.2 1.2,1.2 h 14.9 c 0.5,1.9 2.3,3.4 4.4,3.4 2.5,0 4.6,-2.1 4.6,-4.6 0,-2.5 -1.9,-4.6 -4.4,-4.6 z M 31.6,62.5 c 0,-1.2 1,-2.1 2.1,-2.1 1.2,0 2.1,1 2.1,2.1 0,1.2 -1,2.1 -2.1,2.1 -1.1,0 -2.1,-1 -2.1,-2.1 z M 53.1,84 c -1.2,0 -2.2,-1 -2.2,-2.2 0,-1.2 1,-2.2 2.2,-2.2 1.2,0 2.2,1 2.2,2.2 0,1.2 -1,2.2 -2.2,2.2 z"
       id="path2" /><path
       d="m 43.4,41.9 c -0.7,0 -1.2,0.5 -1.2,1.2 v 29 c 0,0.7 0.5,1.2 1.2,1.2 h 5.3 c 0.5,1.9 2.3,3.3 4.4,3.3 2.5,0 4.6,-2 4.6,-4.6 0,-2.5 -2,-4.6 -4.6,-4.6 -2.1,0 -3.8,1.4 -4.4,3.3 H 44.6 V 43.1 c 0,-0.6 -0.5,-1.2 -1.2,-1.2 z M 53.1,70 c 1.2,0 2.1,1 2.1,2.1 0,1.1 -1,2.1 -2.1,2.1 -1.2,0 -2.1,-1 -2.1,-2.1 C 51,71 51.9,70 53.1,70 Z"
       id="path3" /><path
       d="M 73.6,67.7 V 52.8 c 0,-0.7 -0.5,-1.2 -1.2,-1.2 H 64 V 43.2 C 64,42.5 63.5,42 62.8,42 c -0.7,0 -1.2,0.5 -1.2,1.2 v 9.7 c 0,0.7 0.5,1.2 1.2,1.2 h 8.4 v 13.7 c -1.9,0.5 -3.4,2.3 -3.4,4.4 0,2.5 2.1,4.6 4.6,4.6 2.5,0 4.6,-2.1 4.6,-4.6 0,-2.2 -1.4,-4 -3.4,-4.5 z m -1.2,6.6 c -1.2,0 -2.2,-1 -2.2,-2.2 0,-1.2 1,-2.2 2.2,-2.2 1.2,0 2.2,1 2.2,2.2 0,1.2 -1,2.2 -2.2,2.2 z"
       id="path4" /><path
       d="m 33.8,41.9 c -0.7,0 -1.2,0.5 -1.2,1.2 v 5.2 c -1.9,0.5 -3.4,2.3 -3.4,4.4 0,2.5 2.1,4.6 4.6,4.6 2.5,0 4.6,-2.1 4.6,-4.6 0,-2.1 -1.4,-3.9 -3.4,-4.4 v -5.2 c 0,-0.6 -0.6,-1.2 -1.2,-1.2 z m 2.1,10.9 c 0,1.2 -1,2.2 -2.2,2.2 -1.2,0 -2.2,-1 -2.2,-2.2 0,-1.2 1,-2.2 2.2,-2.2 1.2,0 2.2,1 2.2,2.2 z"
       id="path5" /><path
       d="M 83.7,36.9 C 83.4,24 72.8,13.6 59.8,13.6 c -8.1,0 -15.5,4 -19.9,10.6 -1.4,-0.5 -2.8,-0.8 -4.3,-0.8 -5.7,0 -10.7,4 -12.1,9.4 -0.4,0 -0.8,0 -1.2,0 -9.3,0 -16.9,7.6 -16.9,16.9 0,9.2 7.4,16.6 16.9,16.8 h 0.4 c 0.2,0 0.5,0 0.8,0 h 2.8 c 0.7,0 1.2,-0.5 1.2,-1.2 0,-0.7 -0.5,-1.2 -1.2,-1.2 h -2.8 c -0.3,0 -0.5,0 -0.7,0 H 22.3 C 14.2,64 7.8,57.6 7.8,49.8 c 0,-8 6.5,-14.5 14.5,-14.5 0.7,0 1.4,0 2,0.1 0.7,0.1 1.3,-0.4 1.4,-1 0.7,-4.9 5,-8.5 9.9,-8.5 1.5,0 2.9,0.3 4.2,1 0.6,0.3 1.2,0.1 1.6,-0.5 C 45.3,19.9 52.2,16 59.8,16 c 11.9,0 21.5,9.6 21.5,21.5 v 0.3 c 0,0.6 0.4,1.1 1,1.2 5.8,1.3 10,6.5 10,12.5 0,6.6 -5.2,12.2 -11.8,12.7 -0.6,0 -1.1,0.1 -1.7,0 -0.7,0 -1.2,0.5 -1.3,1.1 0,0.7 0.5,1.2 1.1,1.3 0.3,0 0.6,0 0.8,0 0.4,0 0.8,0 1.2,-0.1 7.8,-0.6 14,-7.3 14,-15.2 0,-6.5 -4.5,-12.5 -10.9,-14.4 z"
       id="path6" /></g></svg>
`,_0=`<?xml version="1.0" encoding="UTF-8"?>
<svg width="62" height="55.9" enable-background="new 0 0 64 64" version="1.1" viewBox="0 0 62 55.9" xml:space="preserve" xmlns="http://www.w3.org/2000/svg"><g transform="translate(-1,-4.05)"><path d="m47.5 36.2-15-10c-0.3-0.2-0.8-0.2-1.1 0l-15 10c-0.2 0.2-0.4 0.5-0.4 0.8v12c0 0.3 0.2 0.6 0.5 0.8l15 10c0.3 0.2 0.8 0.2 1.1 0l15-10c0.3-0.2 0.5-0.5 0.5-0.8v-12c-0.1-0.3-0.3-0.6-0.6-0.8zm-25.2 6.1 4-4c0.9-0.9 2.3 0.5 1.4 1.4l-3.3 3.3 3.3 3.3c0.4 0.4 0.4 1 0 1.4s-1 0.4-1.4 0l-4-4c-0.4-0.4-0.4-1 0-1.4zm7.7 5.7c-0.2 0-0.3 0-0.5-0.1-0.5-0.2-0.7-0.8-0.4-1.3l4-8c0.6-1.2 2.4-0.3 1.8 0.9l-4 8c-0.2 0.3-0.5 0.5-0.9 0.5zm11.7-4.3-4 4c-0.4 0.4-1 0.4-1.4 0s-0.4-1 0-1.4l3.3-3.3-3.3-3.3c-0.9-0.9 0.5-2.3 1.4-1.4l4 4c0.4 0.4 0.4 1 0 1.4z"/><path d="m3 26.5v-11l14-9.3 14 9.3v7.5c0 1.3 2 1.3 2 0v-8c0-0.3-0.2-0.6-0.4-0.8l-15-10c-0.3-0.2-0.8-0.2-1.1 0l-15 10c-0.3 0.2-0.5 0.5-0.5 0.8v12c0 0.3 0.2 0.6 0.4 0.8l11.7 7.8c0.2 0.1 0.4 0.2 0.6 0.2 1 0 1.4-1.3 0.6-1.8-0.1-0.1-11.3-7.5-11.3-7.5z"/><path d="m62.6 14.2-15-10c-0.3-0.2-0.8-0.2-1.1 0l-11.7 7.8c-0.5 0.3-0.6 0.9-0.3 1.4s0.9 0.6 1.4 0.3l11.1-7.5 14 9.3v10.9l-11.2 7.5c-1.1 0.7 0 2.4 1.1 1.7l11.7-7.8c0.3-0.2 0.4-0.5 0.4-0.8v-12c0-0.3-0.2-0.6-0.4-0.8z"/><path d="m10.2 25.6c0.4 0.4 1 0.5 1.4 0.1l6-5c0.2-0.2 0.4-0.5 0.4-0.8s-0.1-0.6-0.4-0.8l-6-5c-1-0.8-2.3 0.7-1.3 1.5l5.1 4.2-5.1 4.2c-0.4 0.6-0.4 1.2-0.1 1.6z"/><path d="m19 26h6c1.3 0 1.3-2 0-2h-6c-1.3 0-1.3 2 0 2z"/><path d="m43 25h8c1.3 0 1.3-2 0-2h-8c-1.3 0-1.3 2 0 2z"/><path d="m43 19h8c1.3 0 1.3-2 0-2h-8c-1.3 0-1.3 2 0 2z"/></g></svg>
`,z0=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
   version="1.1"
   x="0px"
   y="0px"
   viewBox="0 0 63.565453 63.381138"
   xml:space="preserve"
   id="svg11"
   sodipodi:docname="noun-agile-3718887.svg"
   width="63.565453"
   height="63.381138"
   inkscape:version="1.3.1 (91b66b0783, 2023-11-16)"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg"><defs
     id="defs11" /><sodipodi:namedview
     id="namedview11"
     pagecolor="#ffffff"
     bordercolor="#000000"
     borderopacity="0.25"
     inkscape:showpageshadow="2"
     inkscape:pageopacity="0.0"
     inkscape:pagecheckerboard="0"
     inkscape:deskcolor="#d1d1d1"
     inkscape:zoom="3.5532116"
     inkscape:cx="-6.4730173"
     inkscape:cy="46.999734"
     inkscape:window-width="1920"
     inkscape:window-height="1008"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="1"
     inkscape:current-layer="g7" /><g
     id="g10"
     transform="translate(-1.4345461,-0.78630491)"><path
       d="m 31.619062,38.618655 c 3.384458,0 6.138215,-2.753757 6.138215,-6.138215 0,-3.384458 -2.753757,-6.138215 -6.138215,-6.138215 -3.384458,0 -6.138215,2.753757 -6.138215,6.138215 0,3.384458 2.753757,6.138215 6.138215,6.138215 z m 0,-10.741876 c 2.538919,0 4.603661,2.064742 4.603661,4.603661 0,2.538919 -2.064742,4.603661 -4.603661,4.603661 -2.538919,0 -4.603661,-2.064742 -4.603661,-4.603661 0,-2.538919 2.064742,-4.603661 4.603661,-4.603661 z"
       id="path1"
       style="stroke-width:0.767277" /><path
       d="m 25.049062,44.29444 1.748,-0.836 c 0.156,0.069 0.313,0.135 0.471,0.196 l 0.643,1.826 h 7.415 l 0.645,-1.826 c 0.157,-0.062 0.314,-0.127 0.471,-0.196 l 1.748,0.836 5.244,-5.244 -0.836,-1.748 c 0.069,-0.156 0.135,-0.313 0.196,-0.471 l 1.825,-0.643 v -7.415 l -1.826,-0.645 c -0.062,-0.157 -0.127,-0.314 -0.196,-0.471 l 0.836,-1.748 -5.244,-5.244 -1.748,0.836 c -0.156,-0.069 -0.313,-0.135 -0.471,-0.196 l -0.643,-1.825 h -7.415 l -0.645,1.826 c -0.157,0.062 -0.314,0.127 -0.471,0.196 l -1.748,-0.836 -5.244,5.244 0.836,1.748 c -0.069,0.156 -0.135,0.313 -0.196,0.471 l -1.825,0.643 v 7.415 l 1.826,0.645 c 0.062,0.157 0.127,0.314 0.196,0.471 l -0.836,1.748 z m -4.43,-9.522 v -4.585 l 1.392,-0.491 0.157,-0.458 c 0.131,-0.383 0.292,-0.769 0.478,-1.147 l 0.213,-0.435 -0.638,-1.334 3.242,-3.242 1.334,0.638 0.435,-0.213 c 0.378,-0.186 0.764,-0.346 1.147,-0.478 l 0.458,-0.157 0.49,-1.39 h 4.585 l 0.491,1.392 0.458,0.157 c 0.383,0.131 0.769,0.292 1.147,0.478 l 0.435,0.213 1.334,-0.638 3.242,3.242 -0.638,1.334 0.213,0.435 c 0.186,0.378 0.346,0.764 0.478,1.147 l 0.157,0.458 1.39,0.49 v 4.585 l -1.392,0.491 -0.157,0.458 c -0.131,0.383 -0.292,0.769 -0.478,1.147 l -0.213,0.435 0.638,1.334 -3.242,3.242 -1.334,-0.638 -0.435,0.213 c -0.378,0.186 -0.764,0.346 -1.147,0.478 l -0.458,0.157 -0.49,1.39 h -4.585 l -0.491,-1.392 -0.458,-0.157 c -0.383,-0.131 -0.769,-0.292 -1.147,-0.478 l -0.435,-0.213 -1.334,0.638 -3.242,-3.242 0.638,-1.334 -0.213,-0.435 c -0.186,-0.378 -0.346,-0.764 -0.478,-1.147 l -0.157,-0.458 z"
       id="path3" /><path
       d="M 15.668707,46.648476 H 4.7193526 c -1.8110233,0 -3.2848065,1.473783 -3.2848065,3.284807 v 10.949354 c 0,1.811024 1.4737832,3.284807 3.2848065,3.284807 H 15.668707 c 1.811024,0 3.284807,-1.473783 3.284807,-3.284807 V 49.933283 c 0,-1.811024 -1.473783,-3.284807 -3.284807,-3.284807 z m 1.343692,14.234161 c 0,0.60331 -0.740382,1.293941 -1.343692,1.293941 H 4.7193526 c -0.6033094,0 -1.3436917,-0.690631 -1.3436917,-1.293941 V 49.933283 c 0,-0.60331 0.7403823,-1.343692 1.3436917,-1.343692 H 15.668707 c 0.60331,0 1.343692,0.740382 1.343692,1.343692 z"
       id="path4"
       style="stroke-width:1.09494"
       sodipodi:nodetypes="ssssssssssssssssss" /><path
       d="M 62,24 H 52 c -1.654,0 -3,1.346 -3,3 v 10 c 0,1.654 1.346,3 3,3 h 10 c 1.654,0 3,-1.346 3,-3 V 27 c 0,-1.654 -1.346,-3 -3,-3 z m 1,13 c 0,0.551 -0.449,1 -1,1 H 52 c -0.551,0 -1,-0.449 -1,-1 V 27 c 0,-0.551 0.449,-1 1,-1 h 10 c 0.551,0 1,0.449 1,1 z"
       id="path5" /><polygon
       points="58.293,28.293 53,33.586 51.707,32.293 50.293,33.707 53,36.414 59.707,29.707 "
       id="polygon8"
       transform="translate(2)" /><path
       d="m 46.757,45.03 0.485,1.94 5.684,-1.421 C 48.335,52.661 40.519,57 32,57 28.341,57 24.815,56.228 21.521,54.705 L 20.682,56.52 C 24.241,58.166 28.049,59 32,59 41.059,59 49.379,54.46 54.367,46.996 l 0.641,5.128 1.984,-0.248 -1.14,-9.12 z"
       id="path8" /><path
       d="m 11.973,36.232 -1.945,-0.465 -1.22,5.106 C 7.612,37.913 7,34.938 7,32 7,28.31 7.785,24.757 9.333,21.438 L 7.52,20.592 C 5.848,24.178 5,28.016 5,32 c 0,3.183 0.655,6.394 1.935,9.579 l -4.452,-2.455 -0.966,1.752 8.258,4.552 z"
       id="path9" /><path
       d="M 33.555,9.168 30.303,7 H 32 c 9.355,0 17.856,5.158 22.184,13.461 l 1.773,-0.925 C 51.284,10.57 42.104,5 32,5 H 30.303 L 33.555,2.832 32.446,1.168 25.197,6 l 7.248,4.832 z"
       id="path10" /><path
       d="m 12.115222,57.651915 1.921194,-1.921193 -1.921194,-1.921194 c -0.227756,-0.229485 -0.227756,-0.599723 0,-0.829209 0.227214,-0.227735 0.596154,-0.227735 0.823369,0 l 2.335797,2.335799 c 0.227729,0.229496 0.227729,0.59971 0,0.829208 l -2.335797,2.335797 c -0.22893,0.223563 -0.594439,0.223563 -0.823369,0 -0.230665,-0.228279 -0.230665,-0.600929 0,-0.829208 z M 9.4640915,58.63295 c 0.3127004,0.07654 0.6284755,-0.11397 0.7065795,-0.426282 l 1.167898,-4.671596 c 0.186864,-0.755242 -0.945997,-1.035538 -1.132861,-0.280296 l -1.167899,4.671596 c -0.077379,0.312827 0.1134638,0.62916 0.4262825,0.706578 z M 7.221726,58.481123 c 0.5528165,0.553236 1.3804969,-0.280315 0.8233685,-0.829208 L 6.123901,55.730722 8.0450945,53.809528 c 0.227728,-0.229497 0.227728,-0.599711 0,-0.829209 -0.2272144,-0.227735 -0.596154,-0.227735 -0.8233685,0 l -2.3357978,2.335799 c -0.2277274,0.229496 -0.2277274,0.59971 0,0.829208 z"
       id="path1-3"
       style="stroke-width:0.58395" /><g
       id="g2"
       transform="matrix(0.93414848,0,0,0.93414848,7.4689405,0.78630491)"><path
         d="M 14,0 H 2 C 0.9,0 0,0.9 0,2 v 16 c 0,1.1 0.9,2 2,2 h 9.5 c -1,-1.1 -1.5,-2.5 -1.5,-4 0,-3.3 2.7,-6 6,-6 V 2 C 16,0.9 15.1,0 14,0 Z M 8,17 H 3 C 2.4,17 2,16.6 2,16 2,15.4 2.4,15 3,15 h 5 c 0.6,0 1,0.4 1,1 0,0.5 -0.4,1 -1,1 z M 8,13 H 3 C 2.4,13 2,12.6 2,12 2,11.4 2.4,11 3,11 h 5 c 0.6,0 1,0.4 1,1 0,0.5 -0.4,1 -1,1 z M 10,9 H 3 C 2.4,9 2,8.5 2,8 2,7.4 2.4,7 3,7 h 7 c 0.6,0 1,0.4 1,1 0,0.5 -0.4,1 -1,1 z M 10,5 H 3 C 2.4,5 2,4.5 2,4 2,3.4 2.4,3 3,3 h 7 c 0.6,0 1,0.4 1,1 0,0.5 -0.4,1 -1,1 z"
         id="path2" /><g
         id="g7"
         transform="matrix(0.14158855,0,0,0.14158855,8.8721861,8.9047561)"><path
           d="m 78.34,54.73 c -0.81,-0.16 -1.6,0.36 -1.77,1.17 -0.37,1.83 -0.93,3.63 -1.66,5.35 -0.71,1.69 -1.6,3.32 -2.63,4.84 -1.02,1.51 -2.19,2.93 -3.48,4.22 -1.29,1.29 -2.71,2.46 -4.22,3.48 -1.52,1.03 -3.15,1.91 -4.84,2.63 -1.72,0.73 -3.52,1.29 -5.35,1.66 -3.75,0.77 -7.73,0.77 -11.49,0 -1.83,-0.37 -3.63,-0.93 -5.35,-1.66 -1.69,-0.71 -3.32,-1.6 -4.84,-2.63 C 31.2,72.77 29.78,71.6 28.49,70.31 27.2,69.02 26.03,67.6 25.01,66.09 23.98,64.57 23.1,62.94 22.38,61.25 21.65,59.53 21.09,57.73 20.72,55.9 c -0.38,-1.88 -0.58,-3.81 -0.58,-5.75 0,-1.94 0.2,-3.87 0.58,-5.75 0.37,-1.83 0.93,-3.63 1.66,-5.35 0.71,-1.69 1.6,-3.32 2.63,-4.84 1.02,-1.51 2.19,-2.93 3.48,-4.22 1.29,-1.29 2.71,-2.46 4.22,-3.48 1.52,-1.03 3.15,-1.91 4.84,-2.63 1.72,-0.73 3.52,-1.29 5.35,-1.66 1.88,-0.38 3.81,-0.58 5.75,-0.58 0.83,0 1.5,-0.67 1.5,-1.5 0,-0.83 -0.67,-1.5 -1.5,-1.5 -2.13,0 -4.27,0.22 -6.35,0.64 -2.02,0.41 -4.01,1.03 -5.91,1.84 -1.87,0.79 -3.67,1.77 -5.35,2.9 -1.67,1.13 -3.23,2.42 -4.66,3.85 -1.42,1.42 -2.72,2.99 -3.85,4.66 -1.14,1.68 -2.11,3.48 -2.9,5.35 -0.8,1.9 -1.42,3.89 -1.84,5.92 -0.42,2.07 -0.64,4.21 -0.64,6.35 0,2.14 0.22,4.27 0.64,6.35 0.41,2.03 1.03,4.02 1.84,5.91 0.79,1.87 1.77,3.67 2.9,5.35 1.13,1.67 2.42,3.24 3.85,4.66 1.43,1.43 3,2.72 4.66,3.84 1.68,1.14 3.48,2.12 5.35,2.91 1.9,0.8 3.89,1.42 5.91,1.84 2.08,0.42 4.21,0.64 6.35,0.64 2.14,0 4.27,-0.22 6.35,-0.64 2.02,-0.41 4.01,-1.03 5.91,-1.84 1.87,-0.79 3.67,-1.77 5.35,-2.9 1.67,-1.13 3.23,-2.42 4.66,-3.85 1.43,-1.43 2.72,-2.99 3.85,-4.66 1.14,-1.69 2.12,-3.49 2.9,-5.35 0.8,-1.9 1.42,-3.89 1.84,-5.92 0.16,-0.8 -0.36,-1.59 -1.17,-1.76 z"
           id="path1-2" /><path
           d="m 63.19,26.06 0.28,0.17 c 0.68,0.4 1.35,0.84 1.99,1.3 0.26,0.19 0.56,0.28 0.86,0.28 0.46,0 0.91,-0.21 1.2,-0.62 0.47,-0.66 0.32,-1.59 -0.34,-2.06 -0.71,-0.51 -1.45,-0.99 -2.2,-1.44 l -0.31,-0.18 c -0.7,-0.41 -1.61,-0.17 -2.02,0.53 -0.41,0.7 -0.17,1.61 0.54,2.02 z"
           id="path2-9" /><path
           d="m 75.87,41.91 c 0.2,0.63 0.78,1.03 1.41,1.03 0.15,0 0.3,-0.02 0.44,-0.07 0.78,-0.24 1.21,-1.07 0.97,-1.85 -0.3,-0.95 -0.65,-1.89 -1.04,-2.81 -0.32,-0.75 -1.19,-1.1 -1.94,-0.78 -0.75,0.32 -1.1,1.19 -0.78,1.94 0.35,0.83 0.67,1.68 0.94,2.54 z"
           id="path3-1" /><path
           d="m 71.71,33.72 0.11,0.15 c 0.29,0.4 0.74,0.62 1.2,0.62 0.3,0 0.6,-0.09 0.86,-0.27 0.66,-0.47 0.82,-1.4 0.35,-2.06 L 74.1,31.98 c -0.55,-0.74 -1.13,-1.47 -1.74,-2.16 -0.54,-0.61 -1.47,-0.67 -2.08,-0.13 -0.61,0.54 -0.67,1.47 -0.13,2.08 0.53,0.62 1.06,1.28 1.56,1.95 z"
           id="path4-2" /><path
           d="m 80.01,47.86 c -0.07,-0.81 -0.77,-1.42 -1.59,-1.35 -0.81,0.06 -1.42,0.78 -1.35,1.59 0.03,0.37 0.05,0.73 0.06,1.1 0.01,0.37 0.02,0.73 0.02,1.1 v 0.5 c -0.01,0.82 0.64,1.49 1.45,1.5 0.01,0 0.02,0 0.03,0 0.8,0 1.46,-0.65 1.48,-1.45 V 50.3 c 0,-0.41 -0.01,-0.81 -0.02,-1.22 -0.02,-0.4 -0.04,-0.81 -0.08,-1.22 z"
           id="path5-7" /><path
           d="m 54.79,22.86 c 0.88,0.18 1.76,0.41 2.62,0.68 0.15,0.04 0.29,0.07 0.44,0.07 0.63,0 1.22,-0.41 1.41,-1.04 0.24,-0.78 -0.2,-1.61 -0.97,-1.85 -0.95,-0.29 -1.92,-0.54 -2.9,-0.75 -0.79,-0.17 -1.58,0.35 -1.74,1.15 -0.17,0.79 0.34,1.57 1.14,1.74 z"
           id="path6" /><path
           d="m 50.14,30.46 c 0,-0.83 -0.67,-1.5 -1.5,-1.5 -0.83,0 -1.5,0.67 -1.5,1.5 v 19.69 c 0,0.55 0.3,1.06 0.79,1.32 l 12.78,6.91 c 0.23,0.12 0.47,0.18 0.71,0.18 0.53,0 1.05,-0.29 1.32,-0.79 0.39,-0.73 0.12,-1.64 -0.61,-2.03 l -12,-6.48 v -18.8 z"
           id="path7" /></g></g></g></svg>
`,b0=`<?xml version="1.0" encoding="UTF-8"?>
<svg width="24.844" height="27.654" data-name="Layer 1" version="1.1" viewBox="0 0 24.844 27.654" xmlns="http://www.w3.org/2000/svg">
 <path d="m3.923 8.242v2.331l3.433-2.331h1.711c1.426 0 2.585-1.159 2.585-2.584v-3.074c0-1.425-1.159-2.584-2.585-2.584h-6.483c-1.425 0-2.584 1.159-2.584 2.584v3.074c0 1.425 1.159 2.584 2.584 2.584zm-2.845-2.584v-3.074c0-0.83 0.676-1.506 1.506-1.506h6.482c0.831 0 1.507 0.676 1.507 1.506v3.074c0 0.83-0.676 1.506-1.507 1.506h-2.043l-2.022 1.374v-1.374h-2.417c-0.83 0-1.506-0.676-1.506-1.506z"/>
 <path d="m20.858 17.082h-6.483c-1.425 0-2.584 1.159-2.584 2.584v3.073c0 1.426 1.159 2.585 2.584 2.585h1.339v2.33l3.433-2.33h1.712c1.425 0 2.584-1.159 2.584-2.585v-3.073c0-1.425-1.159-2.584-2.584-2.584zm1.506 5.657c0 0.831-0.676 1.507-1.506 1.507h-2.044l-2.022 1.373v-1.373h-2.417c-0.83 0-1.506-0.676-1.506-1.507v-3.073c0-0.83 0.676-1.506 1.506-1.506h6.483c0.83 0 1.506 0.676 1.506 1.506z"/>
 <path d="m24.645 12.133c-0.235-0.741-0.758-1.277-1.472-1.51-1.1-0.358-2.529 0.02-3.935 1.05-0.568 0.412-1.156 0.838-1.766 1.176-0.436 0.243-1.091 0.419-1.503 0.111-0.382-0.282-0.445-0.883-0.449-1.221-0.016-0.744 0.165-1.484 0.356-2.268 0.199-0.816 0.405-1.66 0.387-2.547-0.027-1.168-0.653-2.366-1.458-3.301 3.454 0.592 6.417 2.816 7.945 6.065l0.975-0.459c-1.916-4.074-5.882-6.685-10.365-6.835l-0.068-5e-3h-7e-3 -0.016c-0.238-0.014-0.47-9e-3 -0.707 0l0.033 1.078c0.12-4e-3 0.24-6e-3 0.359-6e-3h0.12c1.035 0.762 2.081 2.232 2.109 3.488 0.016 0.743-0.165 1.483-0.356 2.267-0.199 0.816-0.405 1.661-0.387 2.541 0.011 0.934 0.317 1.649 0.886 2.069 0.82 0.611 1.918 0.383 2.668-0.035 0.665-0.368 1.28-0.814 1.892-1.258 1.095-0.801 2.198-1.132 2.951-0.886 0.386 0.126 0.647 0.399 0.778 0.811 0.154 0.49 0.153 1.132 0.152 1.697v0.118c0 1.084-0.161 2.157-0.479 3.188l1.029 0.318c0.35-1.135 0.527-2.314 0.527-3.507v-0.117c0-0.644 2e-3 -1.373-0.203-2.023z"/>
 <path d="m8.154 22.609c-0.265-0.802-0.301-1.665-0.339-2.578l-0.01-0.212c-0.045-1.027-0.127-2.114-0.566-3.1-0.335-0.752-0.861-1.398-1.325-1.969-0.659-0.809-1.314-1.47-2.008-2.17l-0.331-0.334c-0.486-0.494-0.792-0.783-0.996-0.962 0.193-0.67 0.436-1.327 0.762-1.957l-0.957-0.494c-0.875 1.691-1.318 3.521-1.318 5.44 0 5.288 3.465 9.792 8.288 11.323 0.034 0.013 0.065 0.033 0.1 0.044l4e-3 -0.013c0.907 0.279 1.855 0.465 2.842 0.518l0.059-1.076c-0.921-0.05-1.804-0.226-2.647-0.49-0.716-0.297-1.305-1.212-1.557-1.97zm-6.011-8.336c0-0.602 0.066-1.19 0.161-1.771 0.139 0.135 0.303 0.298 0.503 0.501l0.332 0.336c0.676 0.681 1.312 1.324 1.938 2.092 0.442 0.544 0.899 1.105 1.177 1.728 0.363 0.813 0.432 1.745 0.475 2.708l9e-3 0.209c0.039 0.947 0.08 1.927 0.393 2.872 0.062 0.186 0.146 0.384 0.241 0.584-3.141-1.898-5.228-5.345-5.228-9.259z"/>
</svg>
`,S0=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Created with Inkscape (http://www.inkscape.org/) -->

<svg
   version="1.1"
   id="svg1"
   width="335.80475"
   height="378.47653"
   viewBox="0 0 335.80474 378.47653"
   sodipodi:docname="platzi-logo2.svg"
   inkscape:version="1.3.1 (91b66b0783, 2023-11-16)"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg">
  <defs
     id="defs1" />
  <sodipodi:namedview
     id="namedview1"
     pagecolor="#ffffff"
     bordercolor="#000000"
     borderopacity="0.25"
     inkscape:showpageshadow="2"
     inkscape:pageopacity="0.0"
     inkscape:pagecheckerboard="0"
     inkscape:deskcolor="#d1d1d1"
     inkscape:zoom="0.32966642"
     inkscape:cx="-30.333693"
     inkscape:cy="382.20453"
     inkscape:window-width="1920"
     inkscape:window-height="1008"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="1"
     inkscape:current-layer="group-R5">
    <inkscape:page
       x="0"
       y="0"
       inkscape:label="1"
       id="page1"
       width="335.80475"
       height="378.47653"
       margin="0"
       bleed="0" />
  </sodipodi:namedview>
  <g
     id="g1"
     inkscape:groupmode="layer"
     inkscape:label="1"
     transform="translate(1.8283369e-4,-0.00395034)">
    <g
       id="group-R5">
      <path
         id="path2"
         d="m 266.94039,149.7324 c -0.29379,-1.45158 -1.3958,-2.07635 -2.20527,-2.89078 -24.80345,-24.83319 -49.64904,-49.630444 -74.4091,-74.507028 -1.8681,-1.874297 -2.88459,-2.230067 -4.96838,-0.135118 -38.16277,38.310286 -76.405,76.539996 -114.697069,114.710206 -1.941732,1.93504 -1.782318,2.87963 0.06111,4.71674 38.285619,38.18137 76.522769,76.41244 114.697939,114.70302 1.8681,1.87541 2.83004,1.94942 4.72293,0.0257 11.55941,-11.75018 23.21674,-23.39388 34.95342,-34.97163 1.92264,-1.89339 2.16188,-2.94706 0.0917,-4.98078 -11.68089,-11.46792 -23.13741,-23.14881 -34.8183,-34.61028 -2.15073,-2.11354 -2.38873,-3.16598 -0.0793,-5.45183 24.83939,-24.62494 49.54987,-49.3912 74.28638,-74.12027 0.82682,-0.82806 1.61026,-1.69827 2.36394,-2.48791 m -0.0545,159.79004 c -12.61308,12.5201 -25.27574,25.00426 -37.82684,37.58635 -6.02204,6.04705 -12.68001,11.14303 -20.74123,13.99753 -22.05274,7.83476 -42.51878,4.61273 -59.26721,-11.81556 C 108.35217,309.35001 68.130518,268.92109 27.995146,228.40454 6.3343075,206.54146 6.4263117,171.80994 28.13609,149.92331 68.124196,109.6036 108.297,69.462405 148.61051,29.460044 170.27649,7.9651277 205.03404,7.9105846 226.84754,29.355916 c 27.21698,26.763278 54.2071,53.765802 80.99394,80.957984 21.18253,21.50731 21.68581,55.62151 0.66195,77.42261 -24.77246,25.67241 -50.32835,50.59858 -75.53591,75.85424 -0.91856,0.91856 -1.76397,1.90541 -2.65278,2.85992 -2.48666,1.44675 -2.43832,2.73335 -0.32478,4.8035 11.73048,11.53462 23.32707,23.20447 34.92242,34.87916 0.9074,0.9074 2.57344,1.54469 1.97347,3.38911"
         style="fill:#82ce41;fill-opacity:1;fill-rule:nonzero;stroke:none;stroke-width:0.123961" />
    </g>
  </g>
</svg>
`,D0=`<?xml version="1.0" encoding="UTF-8"?>
<svg width="73.2" height="94.422" version="1.1" viewBox="0 0 73.2 94.422" xmlns="http://www.w3.org/2000/svg" xmlns:cc="http://creativecommons.org/ns#" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
 <defs>
  <style>.cls-1{fill:#0356a6;}</style>
 </defs>
 <title>UPAO</title>
 <g transform="translate(.019571 -.68032)" data-name="Capa 2">
  <g data-name="Capa 1">
   <path class="cls-1" d="m73.17 46.72a59.58 59.58 0 0 1-4 22.6 45.83 45.83 0 0 1-10.59 16.28 32.12 32.12 0 0 1-16 8.86 28.49 28.49 0 0 1-18-2 34.32 34.32 0 0 1-10.77-7.66 46.54 46.54 0 0 1-9.81-15.55 57 57 0 0 1-3.42-13.25 58.77 58.77 0 0 1-0.58-9.89 57.29 57.29 0 0 1 5.94-23.89 43.83 43.83 0 0 1 10.22-13.41 31.24 31.24 0 0 1 16.2-7.81 28.34 28.34 0 0 1 15.86 2.17 35.24 35.24 0 0 1 12.21 9 49.74 49.74 0 0 1 11.28 22.6 55 55 0 0 1 1.46 11.95zm-1.06 1.18a53.54 53.54 0 0 0-0.67-8.9 53.44 53.44 0 0 0-5.78-17.5 41.81 41.81 0 0 0-9.91-12.29c-5.94-4.93-12.67-7.63-20.5-7.27a26.51 26.51 0 0 0-6.38 1.06 33.27 33.27 0 0 0-16.61 11.48c-6.8 8.43-10.1 18.23-11 28.91a38.31 38.31 0 0 0-0.09 7.42c0.28 2.35 0.35 4.73 0.75 7.06a51.8 51.8 0 0 0 7.08 18.91 38.21 38.21 0 0 0 13.38 13.29 27.73 27.73 0 0 0 19 3.47 30.52 30.52 0 0 0 15.12-7.54 42.32 42.32 0 0 0 9.76-12.85 56 56 0 0 0 5.85-25.25z"/>
   <path class="cls-1" d="m8.55 49.06c0-8.74 1.52-16 4.9-22.73a34.2 34.2 0 0 1 7.34-10 23.51 23.51 0 0 1 12.21-6.33 21.25 21.25 0 0 1 15 3 30.65 30.65 0 0 1 10.31 10.71 44.28 44.28 0 0 1 5.69 15.67 55 55 0 0 1 0.65 6.55 48.93 48.93 0 0 1-2.65 18.21 37.92 37.92 0 0 1-7 12.65 26 26 0 0 1-11.68 8.21 21 21 0 0 1-15.8-0.94 26.46 26.46 0 0 1-9.17-7.16 41.39 41.39 0 0 1-8.93-19.56 44.16 44.16 0 0 1-0.87-8.28zm29.38-18.56c0-0.07 0.11-0.13 0 0v0 0.06zm12.16 18.86 0.06 0.06h-0.07l-0.42-0.65a2 2 0 0 1 0.55 0.27c0.58 0.58 1.14 1.19 1.78 1.86l-1.4 3.22-4.91-2.55 1.21-3.14-4.19-2.6c-0.64 0.49-1.24 0.91-1.8 1.38a2.1 2.1 0 0 0-0.77 2.52 3 3 0 0 1 0.2 2.13 5.51 5.51 0 0 0 0.27 3.35 4 4 0 0 1-0.19 3.25q-1.06 2.67-2.07 5.36a4.38 4.38 0 0 0-0.16 2.77c0.14 0.52 0.41 0.94 1 1 0.61-0.87-0.41-1.08-0.7-1.72a23.28 23.28 0 0 1 16.74 9.08 33.61 33.61 0 0 0 3.94-6.28 44.28 44.28 0 0 0 4.5-16.67 52.28 52.28 0 0 0-0.31-11 44.47 44.47 0 0 0-4.93-15.25 30.4 30.4 0 0 0-10.42-11.51 21 21 0 0 0-11.16-3.42 20.68 20.68 0 0 0-11.14 3.11 29.87 29.87 0 0 0-10.32 10.77 44.4 44.4 0 0 0-5.91 20.19 48.76 48.76 0 0 0 1.43 15.26 40.36 40.36 0 0 0 6.83 14.48c0.14 0.18 0.31 0.33 0.5 0.53a24.15 24.15 0 0 1 16.94-9.35l-1-1c0.18-1.22 1.27-1.23 2-1.82 0.07-0.75 0.2-1.58 0.21-2.41a6.6 6.6 0 0 1 0.81-3.77l-1.14-1.7-0.13 0.67a2.07 2.07 0 0 1-2.18-0.19 1 1 0 0 0-0.69-0.13 1.11 1.11 0 0 1-1.28-0.84 0.58 0.58 0 0 0-0.1-0.17h-1.03l-0.64-1.17 0.45-1.47a2 2 0 0 0-0.45-0.21c-2.13-0.42-1.92-0.5-2.63-2.46-0.07-0.2-0.14-0.39-0.21-0.62l0.47-0.41a5.51 5.51 0 0 0 0.9 2.19c0.75-1 0.13-2.25 0.86-3.37l0.15 1.41c0.31-0.79 0.59-1.57 0.9-2.34s0.63-1.47 0.95-2.2a4.34 4.34 0 0 1 0 1.44c-0.13 0.84-0.14 0.84 0.21 1.28 0.15-0.6 0.31-1.17 0.44-1.75a48.48 48.48 0 0 1 2-7.57 4.69 4.69 0 0 0 0.24-0.91 1.59 1.59 0 0 0-1.14-1.83 4 4 0 0 0-0.17 0.73c0 0.31 0.12 0.62 0.11 0.93a8.85 8.85 0 0 1-3 6.65c-0.56 0.51-1.2 0.93-1.79 1.39 0.22 0.68 0.49 0.83 1 0.45a16.61 16.61 0 0 0 1.37-1.29 5.93 5.93 0 0 1 0.56-0.43c-0.91 1.57-1.91 3-2.91 4.42a1.08 1.08 0 0 1-0.24 0.18 4.56 4.56 0 0 0-0.41-2.77l-1.46 0.13a2.28 2.28 0 0 1-1.83-1.4l0.36-0.67a7.27 7.27 0 0 1-0.17-2.4 3.63 3.63 0 0 0-0.37-2.06v-0.18h0.69l0.3-1.29c0.65 0 1.3 0.44 1.92-0.13a7.19 7.19 0 0 1-0.1-3.79 12.77 12.77 0 0 0 0-5.4 3 3 0 0 1 0.15-1.33c0.09-0.4 0.29-0.78 0.42-1.18v-0.32l-0.81-0.19a4.27 4.27 0 0 1-0.07-1.73 5 5 0 0 0 0.06-2.49l-1.25-0.53a1.75 1.75 0 0 1-1-2.46c0.74 0 1.06 0.72 1.66 0.92 0.65 0 1.29 0.11 1.93 0.17a1.9 1.9 0 0 1 1.91 1.54c0.11 0.71 0.08 1.44 0.13 2.31l0.66 0.44c-1.54 3.87-0.8 7.78-1 11.6l1.36 0.11 0.81-0.57c0.35 0.15 0.68 0.44 0.9 0.37 1-0.32 1.5 0.25 1.86 1.08a0.92 0.92 0 0 1 1.35 0.42c0.21 0.37 0.48 0.32 0.82 0.14 0.24-0.75 0.55-1.5 0-2.27a2.47 2.47 0 0 1 0-3.27c1.34-0.66 2.7-1.19 4.23-0.45a15.07 15.07 0 0 0 0.15 2.64 5.26 5.26 0 0 1-0.44 3.1l-1.18 0.42 0.23 1.18 2.81 1.75a0.9 0.9 0 0 1 0.3 0.28 6.61 6.61 0 0 1 1.38 4 2.81 2.81 0 0 0 1 2.19 9.88 9.88 0 0 0 1.08 0.82 9.44 9.44 0 0 1 2.56 2.4c-0.16 0-0.32-0.1-0.48-0.13a1.59 1.59 0 0 0-0.29 0l0.16 0.46zm-24.52-10.9 0.05 0.06h-0.06v-0.56l0.94 0.39v-0.68l-0.9-0.14a1.14 1.14 0 0 0-0.03 0.93zm9.43 29.36a1.82 1.82 0 0 0-2-0.82 14.51 14.51 0 0 0-1.45 0.22 19.52 19.52 0 0 0-6.44 2.64 2.85 2.85 0 0 0-1.31 1.5l4.7 3 0.41-0.7a2.43 2.43 0 0 0 2.73 0.53 4.51 4.51 0 0 1 0.81-0.18 1 1 0 0 1 1.13 1 1.49 1.49 0 0 1-0.65 1.45 1.91 1.91 0 0 0-0.8 1.82 2.66 2.66 0 0 1 0 0.63 2.19 2.19 0 0 0 1.47 2.48 7.12 7.12 0 0 1 2.54 2 8 8 0 0 0 0.94 1 1.47 1.47 0 0 0 0.81 0.39 10.4 10.4 0 0 0 5.82-1.35 4.74 4.74 0 0 0 1-0.9c0.52-0.56 1-1.17 1.52-1.72a3.16 3.16 0 0 0 1-2.23 5.69 5.69 0 0 1 0.07-0.83c0.19-1.44 0-1.83-1.34-2.46a8.22 8.22 0 0 0-1.08-0.4 16.18 16.18 0 0 0-4.54-0.65h-0.95l-0.55-1a7.09 7.09 0 0 0-3.55 0.38 2.62 2.62 0 0 1-2 0.06c-1.19-0.39-2.4-0.74-3.59-1.13a3.72 3.72 0 0 1-0.68-0.45c1.29-0.85 2.46-1.67 3.67-2.39a1.86 1.86 0 0 1 1.21-0.16 10.93 10.93 0 0 0 3.33-0.17 3.47 3.47 0 0 0 0.88-0.36 4.25 4.25 0 0 0-3.11-1.2zm3.45-25.5a5.55 5.55 0 0 1-1.45 0.93 6.35 6.35 0 0 1-1.78-0.13 3.77 3.77 0 0 0 0.34 0.78 5.4 5.4 0 0 1 0.79 4.19 4.1 4.1 0 0 0 0.38 3 2.59 2.59 0 0 1 0.21 0.63c-0.86 1.12-0.87 1.7-0.07 2.73 0.17-0.69-0.16-1.43 0.23-2.14 0.39 0.82 0.73 1.53 1.06 2.25 0.22 0.48 0.44 0.95 0.64 1.44a2.83 2.83 0 0 1-0.08 2.43c-1.12 2.18-1.32 4.61-1.89 6.94a2.82 2.82 0 0 0 1.29 2.76c0.13 0.07 0.34 0 0.63 0-0.19-0.21-0.27-0.32-0.37-0.41a3 3 0 0 1-1-3.22 12.85 12.85 0 0 1 0.53-1.7c0.39-1 0.84-2.06 1.23-3.11 0.2-0.55 0.31-1.14 0.46-1.71s0.28-1 0.41-1.44c0-2.16-1.22-4-2.09-5.93 0.49-1.75-0.71-3.26-0.84-5 0.72 0.45 0.41 1.59 1.41 1.77l0.51-0.58 0.76 0.24v-1.32a3.94 3.94 0 0 0-2.17-0.72 7.91 7.91 0 0 1-0.81-0.19c-0.49-0.07-0.56-0.39-0.64-0.77h2.31c0.43 0.79 1.23 0.83 2.12 0.63-0.07 0.78-0.47 1.45-0.16 2.25 1.07-0.7 0.59-2 1.34-2.7a7.13 7.13 0 0 0-0.46-3.44c-0.39 1.17 0.13 2.59-0.92 3.62a3 3 0 0 1-1.94-2.08zm-9.27-15.84 0.07 0.16-0.53 0.41a1.64 1.64 0 0 0-0.62 1.47c0.1 1.28 0.17 2.57 0.2 3.85s0 2.51 0 3.77c0 0.33-0.06 0.73 0.37 0.76l1.33-1.31a3.23 3.23 0 0 1-0.6 2.59 4.46 4.46 0 0 1-4.34 2l0.34 1.59a5.68 5.68 0 0 0 5.08-2.64 6 6 0 0 0 0.65-3.23c0-0.82-0.44-1-1.26-0.86a2.4 2.4 0 0 1-0.46 0.05c-0.13-1.31-0.24-2.56-0.38-3.79a18.15 18.15 0 0 1-0.21-3.84l0.49 0.2a6.28 6.28 0 0 0 0-3.28l0.45-1.25 0.43 0.34-0.14-0.76h-2.9l-0.11 1 0.34-0.43 1.27 0.17c-0.27 0.67-0.48 1.3-0.79 1.89a2.86 2.86 0 0 0-0.32 2.19l0.51-1.63 0.32 0.69zm7.22 10-1 4.48v-0.07c0.33 0.84 0.78 1.2 1.4 1.13s1.07-0.43 1.28-1.29c0.07-0.28 0.16-0.56 0.23-0.84 0.32 1.19 0.45 2.4 1.67 3a1.08 1.08 0 0 0 0.77-1.07c0-0.62-0.07-1.25-0.11-1.87 0-0.24-0.14-0.54 0-0.71 0.42-0.72-0.05-1-0.44-1.38-0.81-0.05-0.77 0.76-1.27 1.11l-0.47-0.97-0.52 0.56c-0.4-1.31-0.86-1.93-1.54-2.12zm-4 14.89c0.23-1.63 0.55-3.06 0.62-4.51a28.1 28.1 0 0 1 0.85-5.23c0.19-0.84 0.42-1.68 0.58-2.54a11.48 11.48 0 0 0 0.1-1.44h-0.27c-1.37 4.28-2.07 8.81-3.28 13.35zm-7-8.4c0.19 0.91 0.36 1.11 1 1a6.72 6.72 0 0 0 3-1.39 11.4 11.4 0 0 0 2.6-3.23 5.77 5.77 0 0 0 0.75-3.52c-0.05-0.47-0.11-1-0.84-1v2.44a5 5 0 0 1-2.28 4.23 7.68 7.68 0 0 1-4.21 1.43zm13.6-11.97a2.15 2.15 0 0 0-0.05 1.82 2.29 2.29 0 0 1 0.26 1.69c-0.05 0.3-0.06 0.6-0.1 1l1.44-0.3a10.57 10.57 0 0 0 0.31-1.21 11.84 11.84 0 0 0 0-1.34c-0.52 0-1 0.14-1.14-0.55h1l0.14-1-1-0.51zm-13-12.21c-0.21-0.17-0.37-0.3-0.54-0.42l-0.59-0.45c-0.05 0.9 0.2 1.39 1 1.57a3.42 3.42 0 0 1 2 1.5c0.17 0.22 0.32 0.45 0.46 0.64l1.15 0.05a2.41 2.41 0 0 0-0.39-2.36l-0.55 0.24a2.11 2.11 0 0 0-2.54-0.77zm13.42 18.53-0.1-1.07-1.12-0.58c0.51-0.55 0-1.3 0.55-1.82 0.06-0.06 0-0.28-0.06-0.4-0.19-0.35-0.41-0.69-0.66-1.09a1.16 1.16 0 0 0-0.38 1.33c0.19 0.9 0.25 1.82 0.38 2.82l-0.86-0.26 1.14 1.4zm4.27 6.55a1.9 1.9 0 0 0 0.47 1.75 11.53 11.53 0 0 0 1.76 1.44 11.34 11.34 0 0 0 2 1.08 2.64 2.64 0 0 0-1.5-1.51 5.11 5.11 0 0 1-2.29-2.19 4.26 4.26 0 0 0-0.44-0.57zm-12.14 10.07 0.39-2h-1.1c-0.5 1.35-0.39 1.67 0.71 2zm1.09 0.81c0.44-1.19 0.32-2.26-0.25-2.61a1.94 1.94 0 0 0 0.25 2.61zm11.29-11.37a2.46 2.46 0 0 0-0.29-2c-0.62 0.27-0.65 0.31-0.66 0.77 0.02 0.7 0.16 0.91 0.95 1.23zm-9.26-0.69a3.56 3.56 0 0 0 0.61 3.18 8.61 8.61 0 0 0-0.61-3.18zm2.33-10.69 0.91-0.65 0.43 0.53 0.22-0.92c-1.56 0.3-1.56 0.3-1.56 1.04zm6.25 8.18c-0.41 0.24-1 0.22-0.73 1l0.9-0.29zm-0.9 0c0.49-0.66 0.47-0.7-0.4-1.16zm-2.78 9.14v-1.32c-0.43 0.56-0.49 0.88 0 1.31zm-14.3-9.58 0.21-0.2a5.4 5.4 0 0 0-0.43-0.52s-0.15 0.09-0.33 0.19zm15.26-9.3 0.13-0.2-0.53-0.24-0.08 0.18zm-1.67-0.44h-0.23v0.4h0.14zm0.71 0.16-0.11-0.06-0.17 0.25 0.15 0.08zm-2.29 0.54s0-0.07-0.05-0.08 0 0-0.07 0l0.08 0.12zm-0.12 1.76h0.05v-0.05z"/>
   <path class="cls-1" d="m48.92 87.12c0.13-0.76 0.27-1.4 0.34-2.05a0.74 0.74 0 0 1 0.64-0.77l1.94 3.85-0.7 0.34-1.29-2.56-0.5 2-1.65-0.62-0.13 0.14 1.21 2.22-0.6 0.44c-0.11-0.1-0.21-0.15-0.25-0.23-0.41-0.81-0.78-1.64-1.2-2.44a12.57 12.57 0 0 0-0.73-1.03l0.52-0.34z"/>
   <path class="cls-1" d="m6.08 49.18h-2.84v-0.69l4.08-0.17c0.36 0.48 0.17 0.77-0.22 1.07a14.68 14.68 0 0 0-2 1.86l2.41-0.25 0.14 0.79c-1.42 0.18-2.83-0.22-4.2 0.46l-0.1-0.74 2.72-2.36z"/>
   <path class="cls-1" d="m50.78 12.44a0.81 0.81 0 0 1-0.73-0.86c0-0.88-0.15-1.77-0.25-2.85l-1.35 2.27-0.67-0.32c0.71-1.27 1.72-2.29 2-3.77l0.67 0.36 0.33 3.57 0.16 0.06 1.4-2.47 0.64 0.37z"/>
   <path class="cls-1" d="m20.55 82.06a7.35 7.35 0 0 0-1 0.69c-0.65 0.63-1.26 1.31-1.93 2l-0.55-0.44 0.49-3.25a8.88 8.88 0 0 0-1.85 1.82l-0.6-0.52c0.93-1.09 2.2-1.8 2.74-3.18 0.63 0.21 0.64 0.64 0.55 1.16-0.17 0.92-0.28 1.84-0.45 3a9.37 9.37 0 0 0 2.05-2.23l0.7 0.75-0.23 0.23z"/>
   <path class="cls-1" d="m56.24 18.07-0.46-0.63c1.11-0.88 2.47-1.44 3.2-2.8l0.51 0.62-1 3.41 0.17 0.1 2.23-1.77 0.44 0.6-3.33 2.58-0.51-0.56 0.87-2.92-0.17-0.14z"/>
   <path class="cls-1" d="m65.37 54.34a2.11 2.11 0 0 1 2.11-2.15 2.21 2.21 0 0 1 2.3 2.21 2.21 2.21 0 1 1-4.41-0.06zm2.12 1.37c1.05 0 1.71-0.54 1.68-1.42 0-0.72-0.69-1.21-1.65-1.2h-0.1a1.35 1.35 0 0 0-1.42 1.41c0 0.77 0.56 1.2 1.49 1.21z"/>
   <path class="cls-1" d="m64.32 34.61a2.07 2.07 0 0 1 2.22-2.22 2.25 2.25 0 0 1 2.18 2.22 2.27 2.27 0 0 1-2.24 2.18 2.07 2.07 0 0 1-2.16-2.18zm2.44-1.4a1.69 1.69 0 0 0-1.83 1.49 1.15 1.15 0 0 0 1.27 1.3 1.86 1.86 0 0 0 1.89-1.6 1.27 1.27 0 0 0-1.33-1.19z"/>
   <path class="cls-1" d="m61.29 23.8a2.13 2.13 0 0 1-2.21-2.25 2.2 2.2 0 1 1 2.21 2.25zm-1.56-2.05a1.32 1.32 0 0 0 1.27 1.38 2.21 2.21 0 0 0 1.84-1.74 1.41 1.41 0 0 0-1.24-1.32 2.07 2.07 0 0 0-1.87 1.68z"/>
   <path class="cls-1" d="m38.74 88.29 0.78-0.11 0.28 1.82 1.66-0.33-0.35-1.68 0.82-0.2 0.69 4.21-0.8 0.2-0.22-1.88-1.66 0.31 0.34 1.77-0.76 0.23z"/>
   <path class="cls-1" d="m65.79 51.35a15 15 0 0 1 0-2 1.81 1.81 0 0 1 1.84-1.66 2 2 0 0 1 2.28 1.42 3.31 3.31 0 0 1-0.14 2.29l-0.65-0.08c0.33-0.92 0.74-1.82-0.19-2.53a1.71 1.71 0 0 0-1.79-0.14c-0.77 0.36-0.93 1.06-0.83 1.95l1.48 0.13v0.84z"/>
   <path class="cls-1" d="m69.71 40.89a8 8 0 0 1 0 1.39 1.13 1.13 0 0 1-1.89 0.87c-0.14-0.09-0.27-0.21-0.48-0.36l-1.69 1.48c-0.19-1.27 1-1.58 1.52-2.43l-1.62 0.3-0.17-0.84zm-0.49 1c-0.94-0.1-0.94-0.1-1.47 0.2a0.76 0.76 0 0 0 0.86 0.58c0.39-0.06 0.6-0.33 0.61-0.8z"/>
   <path class="cls-1" d="m62.7 25.15-1.5 0.85-0.37-0.79 3.74-1.72a2 2 0 0 1 0.51 2.19c-0.31 0.52-0.8 0.61-1.93 0.31l-1 1.81c-0.43-0.58-0.44-0.58-0.15-1.22 0.21-0.4 0.4-0.79 0.7-1.43zm0.51-0.17c0.35 0.55 0.72 0.6 1.08 0.37a0.58 0.58 0 0 0 0.1-0.94z"/>
   <path class="cls-1" d="m6.09 29.52a2.7 2.7 0 0 1 2-2.3 1.85 1.85 0 0 1 2 0.75c0.74 1 0.38 2-0.06 3zm3.68 0.58a1.54 1.54 0 0 0-0.75-2c-0.78-0.38-1.53-0.09-2.15 0.9z"/>
   <path class="cls-1" d="m31.54 8.22-0.7-4a2.34 2.34 0 0 1 2.71 0.19 2.13 2.13 0 0 1 0.63 2.28c-0.31 1-1.07 1.44-2.64 1.53zm0.62-0.61c1.13-0.42 1.55-1.13 1.27-2a1.3 1.3 0 0 0-1.76-0.94z"/>
   <path class="cls-1" d="m7.73 52.78a4.36 4.36 0 0 0 0.23 2c0.13 0.87-0.29 1.37-1.19 1.52s-1.77 0.22-2.77 0.36l-0.2-0.66c0.14-0.07 0.22-0.15 0.31-0.16 0.76-0.09 1.53-0.15 2.29-0.25s1-0.41 1-1-0.31-0.92-0.91-0.89c-0.93 0.06-1.86 0.19-2.85 0.3v-0.78z"/>
   <path class="cls-1" d="m66.93 39.22-1.38 1.43c-0.17-0.68-0.17-0.68 1.2-2.28-0.33 0.05-0.57 0.07-0.81 0.12l-0.81 0.21-0.13-0.84 4.12-0.7c0.19 0.74 0.56 1.57-0.18 2.28s-1.31 0.18-2.01-0.22zm0.32-0.9c0.22 0.54 0.5 0.82 1 0.68s0.59-0.42 0.44-1z"/>
   <path class="cls-1" d="m6.62 37.77 1.5 0.23v0.83l-4-0.73c-0.12-1.1 0.21-1.92 0.88-2.1s1.28 0.1 1.64 0.87l1.83-0.87c0.27 0.64-0.19 0.83-0.55 1.06s-0.76 0.4-1.3 0.71zm-2-0.45c0.49 0.17 0.93 0.44 1.43 0.18a0.71 0.71 0 0 0-0.62-0.85c-0.43-0.08-0.64 0.25-0.8 0.67z"/>
   <path class="cls-1" d="m45.92 90.77a5.93 5.93 0 0 1-0.71 0.44 1.31 1.31 0 0 1-1.94-0.76c-0.34-0.9-0.62-1.84-0.94-2.8l0.69-0.3a1.9 1.9 0 0 1 0.17 0.28c0.22 0.77 0.4 1.56 0.64 2.32s0.56 0.92 1.13 0.75a1 1 0 0 0 0.66-1.32c-0.23-0.83-0.54-1.64-0.84-2.54l0.76-0.17c0.42 1.35 0.83 2.64 1.27 4.06l-0.78 0.11z"/>
   <path class="cls-1" d="m9.51 21.68c1-1.77 2.17-2.35 3.39-1.62s1.36 2.05 0.18 3.81zm3.49 1.32c0.37-1.11 0.22-1.71-0.47-2.17s-1.36-0.38-2.28 0.5z"/>
   <path class="cls-1" d="m17.79 11.17c0.6-0.62 1.16-1.24 2.08-1 0.59 0.14 0.81 0.65 0.84 1.77l2.05 0.45c-0.82 1-1.74 0.11-2.78 0.33l1.25 1-0.64 0.65zm1.93 1c0.4-0.43 0.47-0.8 0.13-1.17s-0.64-0.31-1.1 0z"/>
   <path class="cls-1" d="m10.6 26.26 0.87 1.1-0.4 0.78-2.92-3.86h4.76l-0.34 0.75h-1.38zm-0.11-1.26-1.08-0.13 0.74 0.82z"/>
   <path class="cls-1" d="m22 88.16c0.78-0.46 1.55-0.9 2.32-1.38 0.57-0.36 1.13-0.76 1.83-1.24l-0.24 4.82-0.79-0.36v-1.45l-1.12-0.68-1.11 0.88-0.85-0.6zm3.37-0.22-0.07-1-0.73 0.54z"/>
   <path class="cls-1" d="m38.83 7.85h-0.93c-0.14-0.42-0.25-0.78-0.38-1.14a0.87 0.87 0 0 0-0.18-0.2h-1.29l-0.62 1.09h-0.85l2.42-4.29zm-1.61-2-0.42-0.86-0.33 0.77z"/>
   <path class="cls-1" d="m27.86 9.57-0.74 0.32 0.46-4.76a8.52 8.52 0 0 1 1.81 1.58l1.78 1.56-0.91 0.39-0.91-1-1.3 0.51zm1-2.53-0.56-0.6-0.2 0.15v0.86z"/>
   <path class="cls-1" d="m45.45 8.09-1 0.86-0.83-0.32 3.88-3.08v4.83l-0.81-0.26 0.08-1.42zm1.24-1-0.69 0.51 0.74 0.4z"/>
   <path class="cls-1" d="m23 7.26 2.28 2.19a12.53 12.53 0 0 0-0.36-3.14l0.73-0.46 0.48 4.51c-0.33 0.4-0.62 0.25-0.91 0l-1.55-1.36c-0.44-0.39-0.89-0.77-1.43-1.23z"/>
   <path class="cls-1" d="m12.11 76.91a0.45 0.45 0 0 1-0.79 0.12 2.54 2.54 0 0 1-1-2.39 2.11 2.11 0 0 1 1.79-1.7 2 2 0 0 1 2.05 0.77 9.24 9.24 0 0 1 0.84 1.36l-0.52 0.42c-0.09-0.07-0.16-0.09-0.18-0.14-0.1-0.26-0.18-0.53-0.29-0.79a1.28 1.28 0 0 0-1.38-0.89 1.78 1.78 0 0 0-1.55 1.08 1.28 1.28 0 0 0 0.39 1.51c0.18 0.23 0.42 0.44 0.64 0.65z"/>
   <path class="cls-1" d="m7.64 44.47-4.38 1.53v-0.9l3.06-0.82a9.27 9.27 0 0 0-2.88-1.28v-0.9c1.84 0.66 3.74 1.69 4.2 2.37z"/>
   <path class="cls-1" d="m32.7 88.14-0.57 0.38-1-0.42-0.33 1.27 1 0.4c-0.19 0.82-0.75 0.16-1.18 0.36l-0.29 1.23 1.45 0.22c0 0.36-0.19 0.58-0.57 0.49-0.6-0.13-1.2-0.31-1.74-0.45l1-4.18a4.2 4.2 0 0 1 2.19 0.72z"/>
   <path class="cls-1" d="m16.37 77 1.31 1.71-0.61 0.23-0.63-1-1.09 0.78 0.71 1-0.57 0.25-0.57-0.82-1.12 0.85 1.14 1.16c-0.35 0.17-0.66 0.22-0.92-0.1s-0.7-0.92-1-1.38z"/>
   <path class="cls-1" d="m7.72 41.79-4-0.48c-0.29-0.68 0.17-1.36 0.11-2.18l0.71 0.35-0.33 1.05 1.32 0.25 0.25-1.12c0.75 0.1 0.41 0.64 0.41 1.13l1.23 0.21v-1.52c0.67 0.35 0.72 0.75 0.3 2.31z"/>
   <path class="cls-1" d="m57.75 14.27-0.64-0.92-1 0.91 0.64 0.9-0.43 0.24-0.68-0.73-1 0.87 1.15 1.08c-0.73 0.31-0.88 0.2-1.94-1.34l3.15-2.87 1.44 1.59z"/>
   <path class="cls-1" d="m15.28 13.67a10 10 0 0 1 0.92-0.92 1.33 1.33 0 0 1 1.72 0 1.31 1.31 0 0 1 0.14 1.62c-0.1 0.18-0.23 0.33-0.39 0.56l1.23 1-0.51 0.68zm2.06 0.94c0.55-0.44 0.45-0.81 0.08-1.17s-0.62-0.4-1.25 0.06z"/>
   <path class="cls-1" d="m64.07 72.11c-0.61-0.31-1 0.11-1.41 0.29a1.26 1.26 0 0 1-1.58-0.4 1.3 1.3 0 0 1 0-1.63c0.23-0.29 0.49-0.38 0.85 0-0.07 0.1-0.16 0.22-0.24 0.35s-0.16 0.3-0.24 0.47c0.17 0.49 0.46 0.67 0.95 0.41a5.17 5.17 0 0 1 0.74-0.38 1.22 1.22 0 0 1 1.36 0.19 1.16 1.16 0 0 1 0.22 1.35 9.81 9.81 0 0 1-0.51 0.93l-0.68-0.39c0.54-0.54 0.54-0.54 0.54-1.19z"/>
   <path class="cls-1" d="m12.28 71.94c-0.21-0.37-0.09-1-0.76-1-0.51 0.08-0.52 0.59-0.6 1-0.19 1-0.58 1.46-1.21 1.43s-1.15-0.57-1.31-1.47v-0.17l0.68-0.37c0 0.55-0.17 1.16 0.62 1.24 0.51-0.3 0.46-0.86 0.56-1.36a1.19 1.19 0 0 1 1.12-1 1.44 1.44 0 0 1 1.33 1c0.12 0.29 0.09 0.59-0.43 0.7z"/>
   <path class="cls-1" d="m8.89 35.5-0.89-0.23c0.28-0.46 0.66-0.91 0-1.44-0.29 0.2-0.6 0.39-0.89 0.62-0.66 0.54-1.29 0.63-1.78 0.24s-0.66-1.08-0.12-2l0.56 0.13-0.32 0.87a0.68 0.68 0 0 0 1.16 0.16 5.17 5.17 0 0 1 0.71-0.62 1 1 0 0 1 1.68 0.86 8.49 8.49 0 0 1-0.11 1.41z"/>
   <path class="cls-1" d="m56.37 11.71-0.67 0.36-0.77-0.84-2.35 2.91-0.58-0.55 2.39-2.77-1-0.67c0.45-0.44 0.48-0.48 0.77-0.26 0.72 0.57 1.43 1.18 2.21 1.82z"/>
   <path class="cls-1" d="m32.68 88.16a10.18 10.18 0 0 1 3.32 0.24l-0.27 0.57-1.09-0.17-0.34 3.63h-0.76l0.36-3.6-1.21-0.16v-0.53z"/>
   <path class="cls-1" d="m66.15 47c-0.68-0.67-0.22-1.54-0.33-2.35h4.11v2.11l-0.5-0.18 0.15-1.11h-1.31c0 0.15-0.09 0.34-0.12 0.53s0 0.34-0.06 0.51c-0.88 0-0.3-0.69-0.53-1h-1.29l0.14 1.45z"/>
   <path class="cls-1" d="m23.27 84.16-0.58 0.1-0.8-0.72-2.22 2.92-0.67-0.46 2.33-3-1-0.64 0.18-0.36 0.23-0.23c0.73 0.58 1.46 1.14 2.17 1.73a1.9 1.9 0 0 1 0.34 0.59z"/>
   <path class="cls-1" d="m5.46 31.35 0.25-0.77 4 1.23-0.18 0.76z"/>
   <path class="cls-1" d="m15.86 76.29-3.49 2.51-0.43-0.67 3.43-2.44z"/>
   <path class="cls-1" d="m22 88.15-0.91-0.55c0.55-0.74 1.06-1.39 1.5-2.07a11.57 11.57 0 0 0 0.67-1.37c0.46-0.29 0.67 0.13 1 0.31-0.59 0.84-1.19 1.63-1.72 2.46a7.61 7.61 0 0 0-0.54 1.23z"/>
   <path class="cls-1" d="m21.58 8.22 2.27 3.44a0.73 0.73 0 0 1-0.14 0.2 4.27 4.27 0 0 1-0.49 0.28l-2.22-3.47a0.52 0.52 0 0 1 0.13-0.2 3.75 3.75 0 0 1 0.45-0.25z"/>
   <path class="cls-1" d="m3.2 47.23 0.1-0.74 4.14 0.15v0.75z"/>
   <path class="cls-1" d="m49.69 48.75-0.69-0.22z"/>
   <path class="cls-1" d="m28.09 47.47-0.22 0.45z"/>
   <path class="cls-1" d="m27.88 47.89-0.22 0.23z"/>
  </g>
 </g>
 <metadata>
  <rdf:RDF>
   <cc:Work rdf:about="">
    <dc:title>UPAO</dc:title>
   </cc:Work>
  </rdf:RDF>
 </metadata>
</svg>
`,C0=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
   width="362.61874"
   height="373.60001"
   viewBox="0 0 362.61874 373.60001"
   fill="none"
   version="1.1"
   id="svg32"
   sodipodi:docname="logo-upn-nuevo.svg"
   inkscape:version="1.3.1 (91b66b0783, 2023-11-16)"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg">
  <defs
     id="defs32" />
  <sodipodi:namedview
     id="namedview32"
     pagecolor="#ffffff"
     bordercolor="#000000"
     borderopacity="0.25"
     inkscape:showpageshadow="2"
     inkscape:pageopacity="0.0"
     inkscape:pagecheckerboard="0"
     inkscape:deskcolor="#d1d1d1"
     inkscape:zoom="0.69326683"
     inkscape:cx="-150.01439"
     inkscape:cy="72.122302"
     inkscape:window-width="1920"
     inkscape:window-height="1008"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="1"
     inkscape:current-layer="svg32" />
  <path
     d="M 362.61874,0 H 0 v 373.6 h 362.61874 z"
     fill="#fdba30"
     id="path1"
     style="stroke-width:0.672458" />
  <g
     id="g32"
     transform="translate(2,2)">
    <path
       d="M 175.1307,48.201196 V 324.99892 H 134.68078 V 122.19213 l -1.11433,1.00289 c -17.82917,16.82628 -37.664109,31.64677 -58.836249,44.12719 v -45.79867 c 11.14323,-7.80026 21.7293,-16.38055 31.646769,-25.629431 15.37766,-14.374767 29.3067,-30.421018 41.34138,-47.804456 h 27.41235 z"
       fill="#000000"
       id="path5"
       style="stroke-width:1.11432" />
    <path
       d="m 290.57456,121.63497 v 45.79867 C 269.29099,154.95323 249.56748,140.0213 231.73831,123.30645 l -1.11433,-1.00289 V 325.11035 H 190.17406 V 48.200974 h 27.52378 c 12.03469,17.383438 25.85229,33.429689 41.34138,47.804567 9.80604,9.248879 20.39211,17.829169 31.53534,25.629429 z"
       fill="#000000"
       id="path6"
       style="stroke-width:1.11432" />
  </g>
</svg>
`,G0='<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><title>linkedin-flat</title><g id="Linkedin"><circle id="back" cx="256" cy="256" r="256" fill="#0076b2"/><g id="Linkedin-2" data-name="Linkedin"><path d="M116.3,207h59.47V398.16H116.3Zm29.75-95a34.45,34.45,0,1,1-34.47,34.45A34.46,34.46,0,0,1,146.05,112" fill="#fff"/><path d="M213,207h57v26.14h.82c7.92-15,27.31-30.88,56.21-30.88,60.16,0,71.27,39.59,71.27,91.07V398.16H338.9v-93c0-22.17-.38-50.69-30.87-50.69-30.91,0-35.63,24.16-35.63,49.1v94.55H213Z" fill="#fff"/></g></g></svg>',V0=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
   width="1024"
   height="1024"
   viewBox="0 0 1024 1024"
   fill="none"
   version="1.1"
   id="svg1"
   sodipodi:docname="github-icon.svg"
   inkscape:version="1.3.1 (91b66b0783, 2023-11-16)"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg">
  <defs
     id="defs1" />
  <sodipodi:namedview
     id="namedview1"
     pagecolor="#ffffff"
     bordercolor="#000000"
     borderopacity="0.25"
     inkscape:showpageshadow="2"
     inkscape:pageopacity="0.0"
     inkscape:pagecheckerboard="0"
     inkscape:deskcolor="#d1d1d1"
     inkscape:zoom="0.55518931"
     inkscape:cx="203.53418"
     inkscape:cy="833.94977"
     inkscape:window-width="1920"
     inkscape:window-height="1008"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="1"
     inkscape:current-layer="svg1" />
  <path
     fill-rule="evenodd"
     clip-rule="evenodd"
     d="M 8,0 C 3.58,0 0,3.58 0,8 c 0,3.54 2.29,6.53 5.47,7.59 h 5.08 C 13.71,14.53 16,11.53 16,8 16,3.58 12.42,0 8,0 Z"
     transform="scale(64)"
     fill="#1b1f23"
     id="path1"
     sodipodi:nodetypes="ssccss" />
  <path
     id="path2"
     style="fill:#ffffff;fill-opacity:1;stroke-width:1.11774"
     d="m 350.08008,997.75977 c 1.07533,0.18818 1.95917,0.14584 2.97851,0.26562 z m 321.88867,0.35546 c 1.10072,-0.14784 2.06391,-0.12215 3.23047,-0.35546 z m 0,0 C 648.91441,1001.2117 640,986.26699 640,973.43945 c 0,-17.27998 0.64062,-72.31889 0.64062,-140.79883 0,-47.99995 -16.00056,-78.72071 -34.56054,-94.7207 113.91988,-12.79999 233.59961,-56.32098 233.59961,-252.80078 0,-56.31994 -19.8405,-101.75964 -52.48047,-137.59961 5.11999,-12.79999 23.04083,-65.27976 -5.11914,-135.67969 0,0 -42.88088,-14.07946 -140.80078,52.48047 -40.95996,-11.51999 -84.48005,-17.28125 -128,-17.28125 -43.51996,0 -87.04004,5.76126 -128,17.28125 -97.91991,-65.91993 -140.79883,-52.48047 -140.79883,-52.48047 -28.15997,70.39993 -10.24109,122.8797 -5.12109,135.67969 -32.63997,35.83997 -52.47852,81.91967 -52.47852,137.59961 0,195.8398 119.0391,240.00079 232.95898,252.80078 -14.71998,12.79999 -28.16063,35.2005 -32.64062,68.48047 -29.43997,13.43999 -103.03919,35.19969 -149.11914,-42.24023 -9.59999,-15.35999 -38.40075,-53.12047 -78.7207,-52.48047 -42.87996,0.64 -17.27936,24.31993 0.64062,33.91992 21.75998,12.15999 46.72047,57.60033 52.48047,72.32031 10.23999,28.79997 43.52028,83.84013 172.16015,60.16016 0,42.87996 0.63868,83.19939 0.63868,95.35937 0,12.87544 -8.97296,27.31775 -32.22071,24.58594 51.3642,17.66011 105.25996,26.84391 159.57422,27.19141 54.22928,-0.3444 108.04236,-9.4975 159.33594,-27.10157 z"
     sodipodi:nodetypes="cccccccsscscccscccscccccccsccc" />
</svg>
`,$0=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
   viewBox="0 0 1261.8324 1261.8324"
   class="aa bb"
   version="1.1"
   id="svg1"
   sodipodi:docname="medium.icon.sanitized.svg"
   width="1261.8324"
   height="1261.8324"
   inkscape:version="1.3.1 (91b66b0783, 2023-11-16)"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:svg="http://www.w3.org/2000/svg">
  <defs
     id="defs1" />
  <sodipodi:namedview
     id="namedview1"
     pagecolor="#ffffff"
     bordercolor="#000000"
     borderopacity="0.25"
     inkscape:showpageshadow="2"
     inkscape:pageopacity="0.0"
     inkscape:pagecheckerboard="0"
     inkscape:deskcolor="#d1d1d1"
     showguides="false"
     inkscape:zoom="0.26637793"
     inkscape:cx="157.67072"
     inkscape:cy="923.49993"
     inkscape:window-width="1920"
     inkscape:window-height="1008"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="1"
     inkscape:current-layer="svg1" />
  <circle
     style="fill:#000000;fill-opacity:1;stroke-width:1.00188"
     id="path2"
     cx="630.9162"
     cy="630.9162"
     r="630.9162" />
  <g
     data-name="Layer 2"
     id="g1"
     style="fill:#f9f9f9"
     transform="translate(99.358032,356.02695)">
    <path
       d="m 588.67,296.36 c 0,163.67 -131.78,296.35 -294.33,296.35 C 131.79,592.71 0,460 0,296.36 0,132.72 131.78,0 294.34,0 456.9,0 588.67,132.69 588.67,296.36 m 322.89,0 c 0,154.06 -65.89,279 -147.17,279 -81.28,0 -147.17,-124.94 -147.17,-279 0,-154.06 65.88,-279 147.16,-279 81.28,0 147.17,124.9 147.17,279 m 132.08,0 c 0,138 -23.17,249.94 -51.76,249.94 -28.59,0 -51.75,-111.91 -51.75,-249.94 0,-138.03 23.17,-249.94 51.75,-249.94 28.58,0 51.76,111.9 51.76,249.94"
       data-name="Layer 1"
       id="path1"
       style="fill:#f9f9f9" />
  </g>
</svg>
`,A0=[{percent:72,content:{es:"Desarrollo (código)",en:"Desarrollo (código)"}},{percent:16,content:{es:"Levantamiento de definiciones funcionales, investigación, documentación y arquitectura",en:"Levantamiento de definiciones funcionales, investigación, documentación y arquitectura"}},{percent:12,content:{es:"Reuniones de coordinación, daylis y mentoría",en:"Reuniones de coordinación, daylis y mentoría"}}],I0=[{icon:V0},{icon:G0},{icon:$0}],U0=[{desc:"Experiencia como Scrum Master en proyectos Agile",icon:z0},{desc:"Inglés avanzado y español nativo",icon:b0},{desc:"Experiencia en arquitectura cloud, AWS y DevOps",icon:u0},{desc:"Habilidades comunicativas y de coordinación",icon:k0},{desc:"Desarrollo enfocado en escabilidad y mantenibilidad en sistemas complejos",icon:_0}],P0=[{es:"Git, Python, Kotlin y Flutter + Dart",en:""},{es:"AWS: Cloudformation, IAM, API-Gateway, CloudFront",en:""},{es:"Vite.js, Next.js, Service Workers, PWA, WebSockets",en:""},{es:"Cálculos geo-espaciales y renderización de mapas",en:""}],M0=[{name:"Go Programming",years:[[22,6],[23,8],[24,8]]},{name:"C# & .NET Core",years:[[20,6],[21,4],[22,3]]},{name:"Solid.js",years:[[22,3],[23,4],[23,6]]},{name:"ScyllaDB / Cassandra",years:[[23,3],[24,4]]},{name:"Node.js",years:[[19,8],[20,8],[21,6],[22,5],[23,4]]},{name:"React.js",years:[[19,3],[20,5],[21,6],[22,8],[23,6],[23,4]]},{name:"Angular",years:[[20,8],[21,4]]},{name:"PostgreSQL",years:[[20,4],[21,5],[22,8],[23,7]]},{name:"SQL Server",years:[[17,4],[20,8],[21,4]]},{name:"Mongo DB / ArangoDB",years:[[18,7],[19,7]]},{name:"JavaScript & WebAPIs",years:[[17,8],[18,7],[19,7],[20,7],[21,6],[22,6],[23,6],[24,6]]},{name:"Linux / Bash / Nginx / VPS",years:[[16,3],[17,3],[18,2],[19,1],[20,3],[21,2],[22,2],[23,2],[24,2]]},{name:"PHP / Wordpress",years:[[16,5],[17,4],[18,4]]},{name:"AWS Lambda, EC2, ECS, S3",years:[[20,4],[21,4],[22,5],[23,6],[24,6]]},{name:"Docker / Podman",years:[[22,3],[23,6],[24,5]]},{name:"Rust",years:[[21,2],[23,4],[24,5]]},{name:"Google Cloud / Firebase",years:[[21,3],[22,4]]},{name:"DynamoDB",years:[[21,2],[22,2],[22,3],[24,4]]},{name:"Infra & CI/CD Tools",years:[[22,3],[23,3],[24,3]]},{name:"AWS Athena / Glue / ETLs",years:[[22,2],[23,3],[24,2]]}],L0=[{company:"Hortifrut SA",description:["Desarrollo de software empresarial para áreas de producción, sanidad y mejora contínua con React.js, Go, Node.js, PostgreSQL y DynamoDB","Desarrollo sobre servicios AWS como Lambda, S3, ECS, CloudFront, Athena, API-Gateway mediante SDK y CLI","Coordinación con múltiples áreas para el levantamiento técnico-funcional de los proyectos de software"],role:"Full Stack Developer",logo:f0},{company:"Yawi Solutions",role:"Senior Software Developer",logo:v0,description:["Desarrollo de software empresarial con Angular, React.js + Vite.js, C# / .NET Core, Node.js y Go.","Modelado de base de datos Sql-Server y PostgreSQL","Manejo de librerías gráficas (web), estadísticas y geo-espaciales","Diseño de arquitectura cloud en AWS con CloudFormation y en Azure.","Lider técnico del equipo de Software Factory y rol como Scrum Master"]},{company:"Upwork",logo:w0,description:["Desarrollo de un sistemas web con React, Node y MongoDB: Catálogo de cursos para institución educativa","Desarrollo de un gestor de contenidos para páginas web con JavaScript","Desarrollo de un sistema de búsqueda de empleo y scraping con React, Node.js y PostgreSQL"],role:"Freelance Software Developer"},{company:"Unicore",logo:y0,role:"Software Developer & Founder",description:["Desarrollo de un sistema empresarial con módulos de ventas, finanzas, logística, productos y facturación electrónica usando PostgreSQL, DynamoDB, Node.js, React.js y WebSockets","Desarrollo de un páginas webs con CMS e integración con plataformas de pago.","Uso de AWS Lambda, S3, EC2 y Linux VPCs y Bash"]},{company:"Permex International",logoImg:"images/permex4.webp",role:"Jefe de Operaciones",description:["Planificación y control de la producción y el abastecimiento para la producción de chips de carnaza","Gestión de la logística internacional y trámites para la exportación de contenedores a USA","Elaboración de presupuestos, reportes de gastos y gestión financiera."]},{company:"EQUOM SAC",logo:x0,description:["Participación en desarrollo de CompuBox: Mini-PC Linux con procesador ARM","Coordinación con proveedores internacionales, gestión del proceso de importación y manejo financiero"],role:"Jefe de Operaciones"}],H0=[{name:"FORTALEZAS",list:["Balance entre habilidades técnicas y blandas","Experiencia en varios lenguajes y framework permite adoptar nuevas herramientas rápido","Experiencia en arquitectura cloud / AWS","Background en negocios, finanzas y operaciones en empresas industriales","Experiencia desarrollando sobre bases de código grandes con equipos multidiciplinarios"]},{name:"DEBILIDADES",list:["Poca experiencia en kubernetes, MS-Windows y apps móviles","Poca experiencia en Python, AI y ciencia de datos","Tendencia de asumir el riesgo de incorporar nuevas tecnologías"]},{name:"OPORTUNIDADES",list:["Tecnologías actuales"]},{name:"AMENAZAS",list:["TBD"]}],T0=[{name:"Platzi",logo:S0,content:[]},{name:"Uni. Privada Antenor Orrego",logo:D0,content:[]},{name:"Uni. Privada del Norte",logo:C0,content:[]}],F0="_",q0="a",B0="b",O0="c",R0="d",E0="e",j0="f",W0="g",N0="h",Z0="i",Q0="j",J0="k",K0="l",Y0="m",X0="n",n1="o",e1="p",t1="q",a1="r",i1="s",s1="t",t={main:F0,content:q0,about_me_layer:B0,photo_circle:O0,letter:R0,location:E0,location_container:j0,table_header:W0,table_cell:N0,cell_line:Z0,table_main:Q0,table_card:J0,table_card_container:K0,table_card_image_ctn:Y0,table_card_image:X0,foda_card:n1,skill_card:e1,skill_image:t1,skill_descrip:a1,skill_card_container:i1,social_icon:s1},c1=`<?xml version="1.0" encoding="UTF-8"?>
<svg width="41.4" height="64.2" version="1.1" viewBox="0 0 41.4 64.2" xml:space="preserve" xmlns="http://www.w3.org/2000/svg"><g transform="translate(-29.3,-17.9)" fill="#fea"><path d="m68.6 47.6c1.3-2.7 2.1-5.8 2.1-9 0-11.4-9.3-20.7-20.7-20.7s-20.7 9.3-20.7 20.7c0 3.2 0.8 6.3 2.1 9 0 0 0.4 0.9 0.5 1l18.1 33.5 17.9-33c0.2-0.4 0.7-1.5 0.7-1.5zm-18.6-19.3c5.7 0 10.3 4.6 10.3 10.3s-4.6 10.4-10.3 10.4-10.3-4.6-10.3-10.3 4.6-10.4 10.3-10.4z" fill="#fea"/></g></svg>
`,A=c=>`data:image/svg+xml;charset=utf-8,${encodeURIComponent(c)}`;var o1=y("<div><div>"),l1=y('<div><div><div><img src=images/ivan-angulo-profile.webp alt="ivan angulo reyna profile"></div><div><h1 class="h1 bold">Iván J. Angulo Reyna</h1></div><div><img alt=""><div>Trujillo - Perú</div></div><div>ivan@un.pe</div><div><h2 class="h2 bold">Software Developer FullStack</h2></div><div>+ 5 años de experiencia desarrollando sistemas cloud con Node.Js, Go y C# y AWS, Linux, frontend con React y bases de datos SQL.</div><div class=flex></div></div><div><h2 class=bold>Tecnologías / Años de Experiencia</h2><div><table><thead><tr></tr></thead><tbody></tbody></table><div><div class="bold h3 tt-c1">Experiencia adicional en:</div><!$><!/><div></div><div class="bold h3 tt-c1">Día de trabajo habitual:</div><table><tbody></tbody></table></div></div><h2>Skills</h2><div></div><h2 class=bold>Experiencia Laboral</h2><div></div><h2 class=bold>Últimos Proyectos</h2><div><div>● Genix: Sistema de gestión para Mypes (Logística, Comercial, Finanzas)</div><div>● Librería de conversación de imagen .webp y .avif en Go con binarios precompilados hechos en Rust.</div><div>● ORM para ScyllaDB / Cassandra hecho en Go.</div><div>● SmartBerry. Sistema de gestión de producción agrícola de Hortifrut.</div><div>● Sistema de componentes frontend en Solid.Js</div><div>● Jobfinder. Sistema de búsqueda de empleos y scraping.</div><div>● Páginas web y CSM con React + Next.js</div></div><h2 class=bold>F.O.D.A</h2><div></div><h2 class=bold>Estudios</h2><div>'),r1=y('<div><img alt="">'),d1=y("<th>"),p1=y("<tr>"),m1=y("<td>"),h1=y("<div class=flex><div>●</div><div>"),g1=y('<tr><td class="bold h3"></td><td class="">'),f1=y('<div><img alt=""><div>'),v1=y('<div><div class="bold h5 tt-c1 w100 ta-c"></div><!$><!/>'),n0=y("<div>● <!$><!/>"),e0=y('<div><div><div><img alt=""></div><div><div class="h2 bold tt-c1"></div><div></div></div></div><div>'),w1=y("<div>");const y1=17,x1=24,R=c=>typeof c=="string"?c:c.es||c.en;function z1(){const c=[{name:"",setContent:r=>r.name}];for(let r=y1;r<=x1;r++)c.push({name:`${r}`,headerCss:t.table_header,cellCss:t.table_cell,setContent:v=>{const w=v.years.find(g=>g[0]===r);if(!w)return null;let p=0;return p=(w[1]-1)*2,p<3&&(p=3),p>18&&(p=18),(()=>{var g=h(o1),m=g.firstChild;return g.style.setProperty("height","100%"),g.style.setProperty("position","relative"),`${p}px`!=null?m.style.setProperty("height",`${p}px`):m.style.removeProperty("height"),b(()=>e(m,t.cell_line)),g})()}});return(()=>{var r=h(l1),v=r.firstChild,w=v.firstChild,p=w.nextSibling,g=p.nextSibling,m=g.firstChild,V=m.nextSibling,C=g.nextSibling,i=C.nextSibling,f=i.firstChild,x=i.nextSibling,_=x.nextSibling,k=v.nextSibling,T=k.firstChild,I=T.nextSibling,F=I.firstChild,E=F.firstChild,t0=E.firstChild,a0=E.nextSibling,G=F.nextSibling,i0=G.firstChild,s0=i0.nextSibling,[j,c0]=H(s0.nextSibling),U=j.nextSibling,o0=U.nextSibling,l0=o0.nextSibling,r0=l0.firstChild,d0=I.nextSibling,q=d0.nextSibling,p0=q.nextSibling,B=p0.nextSibling,m0=B.nextSibling,W=m0.nextSibling,h0=W.nextSibling,O=h0.nextSibling,g0=O.nextSibling,N=g0.nextSibling;return m.style.setProperty("margin-right","3px"),m.style.setProperty("width","1rem"),m.style.setProperty("height","1rem"),f.style.setProperty("margin-bottom","0"),x.style.setProperty("padding","8px"),x.style.setProperty("text-align","center"),s(_,()=>I0.map(n=>(()=>{var a=h(r1),l=a.firstChild;return b(o=>{var d=t.social_icon,u=A(n.icon);return d!==o.e&&e(a,o.e=d),u!==o.t&&$(l,"src",o.t=u),o},{e:void 0,t:void 0}),a})())),I.style.setProperty("width","100%"),I.style.setProperty("display","flex"),s(t0,()=>c.map(n=>(()=>{var a=h(d1);return s(a,()=>n.name),b(()=>e(a,n.headerCss)),a})())),s(a0,()=>M0.map(n=>(()=>{var a=h(p1);return s(a,()=>c.map(l=>(()=>{var o=h(m1);return s(o,()=>l.setContent(n)),b(()=>e(o,l.cellCss)),o})())),a})())),G.style.setProperty("flex-grow","1"),G.style.setProperty("margin-left","1vw"),G.style.setProperty("display","flex"),G.style.setProperty("flex-direction","column"),s(G,()=>P0.map(n=>(()=>{var a=h(h1),l=a.firstChild,o=l.nextSibling;return l.style.setProperty("width","0.8rem"),s(o,()=>R(n)),a})()),j,c0),U.style.setProperty("width","100%"),U.style.setProperty("border-bottom","1px solid black"),U.style.setProperty("margin","12px 0"),s(r0,()=>A0.map(n=>(()=>{var a=h(g1),l=a.firstChild,o=l.nextSibling;return s(l,()=>`${n.percent}%`),s(o,()=>R(n.content)),a})())),s(q,()=>U0.map(n=>(()=>{var a=h(f1),l=a.firstChild,o=l.nextSibling;return s(o,()=>R(n.desc)),b(d=>{var u=`${t.skill_card}`,S=`${t.skill_image}`,z=A(n.icon),D=`${t.skill_descrip}`;return u!==d.e&&e(a,d.e=u),S!==d.t&&e(l,d.t=S),z!==d.a&&$(l,"src",d.a=z),D!==d.o&&e(o,d.o=D),d},{e:void 0,t:void 0,a:void 0,o:void 0}),a})())),s(B,()=>L0.map(n=>X(k1,{args:n}))),W.style.setProperty("padding-left","0.8rem"),s(O,()=>H0.map(n=>(()=>{var a=h(v1),l=a.firstChild,o=l.nextSibling,[d,u]=H(o.nextSibling);return s(l,()=>n.name),s(a,()=>n.list.map(S=>(()=>{var z=h(n0),D=z.firstChild,P=D.nextSibling,[M,L]=H(P.nextSibling);return s(z,S,M,L),z})()),d,u),b(()=>e(a,t.foda_card)),a})())),s(N,()=>T0.map(n=>X(u1,{args:n}))),b(n=>{var a=t.main,l=t.about_me_layer,o=t.photo_circle,d=`${t.letter}`,u=`flex ${t.location_container}`,S=A(c1),z=`h3 ${t.location}`,D=`h3 ${t.location}`,P=t.letter,M=t.letter,L=t.content,Z=t.table_main,Q=`flex ${t.skill_card_container}`,J=t.table_card_container,K=t.table_card_container,Y=t.table_card_container;return a!==n.e&&e(r,n.e=a),l!==n.t&&e(v,n.t=l),o!==n.a&&e(w,n.a=o),d!==n.o&&e(p,n.o=d),u!==n.i&&e(g,n.i=u),S!==n.n&&$(m,"src",n.n=S),z!==n.s&&e(V,n.s=z),D!==n.h&&e(C,n.h=D),P!==n.r&&e(i,n.r=P),M!==n.d&&e(x,n.d=M),L!==n.l&&e(k,n.l=L),Z!==n.u&&e(F,n.u=Z),Q!==n.c&&e(q,n.c=Q),J!==n.w&&e(B,n.w=J),K!==n.m&&e(O,n.m=K),Y!==n.f&&e(N,n.f=Y),n},{e:void 0,t:void 0,a:void 0,o:void 0,i:void 0,n:void 0,s:void 0,h:void 0,r:void 0,d:void 0,l:void 0,u:void 0,c:void 0,w:void 0,m:void 0,f:void 0}),r})()}const k1=c=>(console.log("logo:: ",c.args.logo),(()=>{var r=h(e0),v=r.firstChild,w=v.firstChild,p=w.firstChild,g=w.nextSibling,m=g.firstChild,V=m.nextSibling,C=v.nextSibling;return v.style.setProperty("display","flex"),s(m,()=>c.args.company),s(V,()=>c.args.role),s(C,()=>c.args.description.map(i=>(()=>{var f=h(n0),x=f.firstChild,_=x.nextSibling,[k,T]=H(_.nextSibling);return s(f,i,k,T),f})())),b(i=>{var f=t.table_card,x=t.table_card_image_ctn,_=t.table_card_image,k=c.args.logoImg||A(c.args.logo);return f!==i.e&&e(r,i.e=f),x!==i.t&&e(w,i.t=x),_!==i.a&&e(p,i.a=_),k!==i.o&&$(p,"src",i.o=k),i},{e:void 0,t:void 0,a:void 0,o:void 0}),r})()),u1=c=>(console.log("logo:: ",c.args.logo),(()=>{var r=h(e0),v=r.firstChild,w=v.firstChild,p=w.firstChild,g=w.nextSibling,m=g.firstChild,V=m.nextSibling,C=v.nextSibling;return v.style.setProperty("display","flex"),s(m,()=>c.args.name),s(V,()=>c.args.content),s(C,()=>c.args.content.map(i=>(()=>{var f=h(w1);return s(f,i),f})())),b(i=>{var f=t.table_card,x=t.table_card_image_ctn,_=t.table_card_image,k=A(c.args.logo);return f!==i.e&&e(r,i.e=f),x!==i.t&&e(w,i.t=x),_!==i.a&&e(p,i.a=_),k!==i.o&&$(p,"src",i.o=k),i},{e:void 0,t:void 0,a:void 0,o:void 0}),r})());export{z1 as default};
